import { prisma } from "../db/client";
import { Extracted } from "../ai/schema";

export interface ContactInput {
  tenantId: string;
  phone: string;
  name?: string | null;
  email?: string | null;
  intent?: string | null;
}

/**
 * Upsert a contact keyed by (tenantId, phone). The DB unique constraint plus
 * this upsert guarantee no duplicate contact per phone+tenant (LAYER 5).
 * On update we never overwrite an existing value with null/empty.
 */
export async function createOrUpdateContact(input: ContactInput) {
  const fields = { name: input.name ?? null, email: input.email ?? null, intent: input.intent ?? null };
  return prisma.contact.upsert({
    where: { tenantId_phone: { tenantId: input.tenantId, phone: input.phone } },
    update: pruneEmpty(fields),
    create: { tenantId: input.tenantId, phone: input.phone, ...fields },
  });
}

function pruneEmpty<T extends Record<string, unknown>>(obj: T): Partial<T> {
  const out: Partial<T> = {};
  for (const [k, v] of Object.entries(obj)) {
    if (v !== null && v !== undefined && v !== "") {
      (out as Record<string, unknown>)[k] = v;
    }
  }
  return out;
}

/** Choose the best phone value: extracted phone if present, else a fallback. */
export function phoneFromExtracted(extracted: Extracted, fallback: string): string {
  const p = (extracted.phone ?? "").trim();
  return p.length > 0 ? p : fallback;
}
