import express from "express";
import { twilioRouter } from "./routes/twilioWebhooks";
import { internalRouter } from "./routes/internal";

export function createApp(): express.Express {
  const app = express();

  // Twilio posts application/x-www-form-urlencoded; internal clients post JSON.
  app.use(express.urlencoded({ extended: false }));
  app.use(express.json());

  app.get("/healthz", (_req, res) => {
    res.json({ ok: true });
  });

  app.use("/webhooks/twilio", twilioRouter);
  app.use("/internal", internalRouter);

  return app;
}
