import { env } from "../config/env";
import { prisma, disconnectDb } from "./client";
import { logger } from "../utils/logger";

/** Seed a single default tenant routed to TWILIO_PHONE_NUMBER. */
async function seed(): Promise<void> {
  const notifyEmail = process.env.SEED_NOTIFY_EMAIL || "owner@example.com";
  const tenant = await prisma.tenant.upsert({
    where: { phoneNumber: env.TWILIO_PHONE_NUMBER },
    update: { notifyEmail },
    create: {
      name: process.env.SEED_BUSINESS_NAME || "Acme Services",
      businessType: process.env.SEED_BUSINESS_TYPE || "home services company",
      phoneNumber: env.TWILIO_PHONE_NUMBER,
      greeting:
        process.env.SEED_GREETING || "Thanks for calling Acme Services. How can I help you today?",
      notifyEmail,
    },
  });
  logger.info(`Seeded tenant ${tenant.id} (${tenant.name}) -> notify ${tenant.notifyEmail}`);
  if (notifyEmail === "owner@example.com") {
    logger.warn("Set SEED_NOTIFY_EMAIL to your real email to receive call summaries.");
  }
  await disconnectDb();
}

seed().catch(async (err) => {
  logger.error(`Seed failed: ${(err as Error).message}`);
  await disconnectDb();
  process.exit(1);
});
