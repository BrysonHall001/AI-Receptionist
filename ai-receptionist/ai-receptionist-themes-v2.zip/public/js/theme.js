// Per-portal theming on the client.
//
// SECURITY: presets are applied by setting body[data-theme] to a charset-safe
// id only (real styling is author-written CSS). Custom values are applied with
// the CSSOM API (style.setProperty) using re-validated hex strings and a font
// id mapped to a hardcoded stack — never by building <style> text or innerHTML
// from user input, so there is no parsing context to break out of.
(function (global) {
  const App = global.App || (global.App = {});

  // id -> fixed font stack. The user's choice is an id from this map; their
  // text is never used directly as a CSS value.
  const FONT_STACKS = {
    system: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif',
    rounded: '"Nunito", "Segoe UI", system-ui, sans-serif',
    geometric: '"Poppins", "Century Gothic", system-ui, sans-serif',
    humanist: '"Segoe UI", Candara, "Trebuchet MS", system-ui, sans-serif',
    serif: 'Georgia, "Times New Roman", serif',
    mono: '"JetBrains Mono", ui-monospace, SFMono-Regular, Menlo, monospace',
  };

  const HEX_RE = /^#([0-9a-fA-F]{3}|[0-9a-fA-F]{6})$/;
  const isHex = (v) => typeof v === "string" && HEX_RE.test(v.trim());
  const DEFAULT_CUSTOM = { background: "#ffffff", fontColor: "#1a1a1e", sidebar: "#ffffff", font: "system" };

  function clearCustom() {
    const s = document.body.style;
    s.removeProperty("--bg");
    s.removeProperty("--ink");
    s.removeProperty("--sidebar-bg");
    s.removeProperty("--font-ui");
  }

  // Apply a theme: { mode:"preset", preset } or { mode:"custom", custom }.
  function applyTheme(theme) {
    const t = theme || {};
    if (t.mode === "custom" && t.custom) {
      const c = t.custom;
      document.body.dataset.theme = "custom";
      clearCustom();
      if (isHex(c.background)) document.body.style.setProperty("--bg", c.background.trim());
      if (isHex(c.fontColor)) document.body.style.setProperty("--ink", c.fontColor.trim());
      if (isHex(c.sidebar)) document.body.style.setProperty("--sidebar-bg", c.sidebar.trim());
      document.body.style.setProperty("--font-ui", FONT_STACKS[c.font] || FONT_STACKS.system);
      return;
    }
    // preset: only allow a charset-safe id (the server already guarantees the
    // stored value is a real preset; this is belt-and-suspenders).
    clearCustom();
    const id = typeof t.preset === "string" && /^[a-z0-9_-]+$/.test(t.preset) ? t.preset : "light";
    document.body.dataset.theme = id;
  }

  function resetToDefault() {
    clearCustom();
    document.body.dataset.theme = "light";
  }

  async function loadAndApply() {
    try {
      const res = await App.portalApi("/api/theme");
      applyTheme(res.theme);
      return res;
    } catch (e) {
      resetToDefault();
      return null;
    }
  }

  // ---- Settings UI ----
  async function mountSettings(host) {
    const { el, esc, toast } = App.util;
    host.innerHTML = `<div class="cell-muted" style="padding:8px 0">Loading themes…</div>`;
    let data;
    try {
      data = await App.portalApi("/api/theme");
    } catch (e) {
      host.innerHTML = `<div class="cell-muted">${esc(e.message)}</div>`;
      return;
    }
    const presets = data.presets || [];
    const fonts = data.fonts || [];
    const current = data.theme || { mode: "preset", preset: "light" };

    // Draft always carries a custom palette (the saved one, or sensible
    // defaults) so a custom design persists even while a preset is active.
    const draft = {
      mode: current.mode === "custom" ? "custom" : "preset",
      preset: current.preset || "light",
      custom: current.custom ? { ...DEFAULT_CUSTOM, ...current.custom } : { ...DEFAULT_CUSTOM },
    };

    host.innerHTML = "";
    const wrap = el("div", "theme-section");
    const basics = presets.filter((p) => p.group === "basic");
    const fun = presets.filter((p) => p.group === "fun");

    function presetCard(p) {
      const c = el("button", "theme-card" + (draft.mode === "preset" && draft.preset === p.id ? " selected" : ""));
      c.type = "button";
      c.dataset.preset = p.id;
      const sw = (p.swatches || []).map((s) => `<span class="theme-swatch" style="background:${cssColor(s)}"></span>`).join("");
      c.innerHTML = `<div class="theme-swatches">${sw}</div><div class="theme-card-name">${esc(p.label)}</div>`;
      c.onclick = () => {
        draft.mode = "preset";
        draft.preset = p.id;
        applyTheme(draft); // live preview (keeps draft.custom for later)
        markSelection();
      };
      return c;
    }

    wrap.appendChild(el("div", "theme-group-label", "Basic"));
    const g1 = el("div", "theme-grid");
    basics.forEach((p) => g1.appendChild(presetCard(p)));
    wrap.appendChild(g1);

    wrap.appendChild(el("div", "theme-group-label", "Fun"));
    const g2 = el("div", "theme-grid");
    fun.forEach((p) => g2.appendChild(presetCard(p)));
    wrap.appendChild(g2);

    // "Your custom theme" — selectable card + the designer controls.
    wrap.appendChild(el("div", "theme-group-label", "Design your own"));
    const customCard = el("div", "theme-card theme-custom-card" + (draft.mode === "custom" ? " selected" : ""));
    customCard.dataset.custom = "1";
    const cu = draft.custom;
    const fontOpts = fonts.map((f) => `<option value="${esc(f.id)}"${f.id === cu.font ? " selected" : ""}>${esc(f.label)}</option>`).join("");
    customCard.innerHTML = `
      <div class="theme-card-name" style="margin-bottom:10px">Your custom theme</div>
      <div class="theme-custom">
        <div class="theme-custom-row"><label>Background color</label><input type="color" id="th-bg" value="${cu.background}"></div>
        <div class="theme-custom-row"><label>Sidebar color</label><input type="color" id="th-side" value="${cu.sidebar}"></div>
        <div class="theme-custom-row"><label>Font color</label><input type="color" id="th-fg" value="${cu.fontColor}"></div>
        <div class="theme-custom-row"><label>Font</label><select id="th-font" class="input">${fontOpts}</select></div>
        <button type="button" id="th-use" class="btn btn-ghost btn-sm">Use this custom theme</button>
      </div>`;
    wrap.appendChild(customCard);

    const saveBar = el("div");
    saveBar.style.marginTop = "14px";
    const saveBtn = el("button", "btn btn-primary btn-sm", "Save theme");
    saveBar.appendChild(saveBtn);
    wrap.appendChild(saveBar);
    host.appendChild(wrap);

    function markSelection() {
      host.querySelectorAll(".theme-card").forEach((node) => {
        const sel = node.dataset.custom ? draft.mode === "custom" : (draft.mode === "preset" && draft.preset === node.dataset.preset);
        node.classList.toggle("selected", !!sel);
      });
    }

    function readCustom() {
      draft.custom = {
        background: host.querySelector("#th-bg").value,
        sidebar: host.querySelector("#th-side").value,
        fontColor: host.querySelector("#th-fg").value,
        font: host.querySelector("#th-font").value,
      };
    }
    // Editing a control switches to custom mode and previews live.
    const onCustomChange = () => { readCustom(); draft.mode = "custom"; applyTheme(draft); markSelection(); };
    ["#th-bg", "#th-side", "#th-fg"].forEach((id) => { host.querySelector(id).oninput = onCustomChange; });
    host.querySelector("#th-font").onchange = onCustomChange;
    host.querySelector("#th-use").onclick = onCustomChange;

    saveBtn.onclick = async () => {
      try {
        const payload = { mode: draft.mode, preset: draft.preset, custom: draft.custom };
        const res = await App.portalApi("/api/theme", { method: "PATCH", body: JSON.stringify({ theme: payload }) });
        applyTheme(res.theme); // apply the server-sanitized version
        toast("Theme saved");
      } catch (e) {
        toast(e.message, true);
      }
    };
  }

  function cssColor(v) { return isHex(v) ? v : "transparent"; }

  App.theme = { applyTheme, resetToDefault, loadAndApply, mountSettings };
})(typeof window !== "undefined" ? window : globalThis);
