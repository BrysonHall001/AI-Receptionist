// Central theme definitions + the server-side sanitizer.
//
// SECURITY: nothing here turns user input into raw CSS. Presets are referenced
// by id only (styling is author-written CSS keyed by a data-theme attribute).
// Custom values are strictly validated: colors must be #rgb/#rrggbb hex, and
// the font must be one of a fixed set of ids. Anything else is rejected and
// replaced with a safe default, so only known-good values can ever be stored.

export type ThemeMode = "preset" | "custom";

export interface CustomTheme {
  background: string; // hex — page background
  fontColor: string; // hex — body text
  sidebar: string; // hex — left navigation background
  font: string; // a FONT id from the allow-list
}

// The stored theme keeps BOTH the active selection and the last-designed custom
// palette, so a saved custom design remains re-selectable after switching to a
// preset and back.
export interface Theme {
  mode: ThemeMode;
  preset?: string; // active preset id (when mode === "preset")
  custom?: CustomTheme; // the saved custom palette (persists across switches)
}

// The shipped presets. Adding one = add an entry here AND a matching
// `body[data-theme="<id>"]` block in public/styles.css. Nothing else to wire.
// swatches are just preview colors for the picker.
export const PRESETS = [
  // ----- Basic (palette only) -----
  { id: "light", label: "Clean Light", group: "basic", swatches: ["#fbfbfa", "#5b59d6", "#1a1a1e"] },
  { id: "warm", label: "Warm Light", group: "basic", swatches: ["#fbf8f3", "#5b59d6", "#2b2722"] },
  { id: "neutral", label: "Neutral Pro", group: "basic", swatches: ["#f5f6f7", "#2f6f8f", "#22282e"] },
  { id: "slate", label: "Slate", group: "basic", swatches: ["#eef1f4", "#4a6076", "#2b3440"] },
  { id: "steel", label: "Steel Blue", group: "basic", swatches: ["#f4f6f9", "#2a4d7a", "#1f2733"] },
  { id: "sand", label: "Sand", group: "basic", swatches: ["#f3ecdf", "#a9763e", "#43392b"] },
  { id: "contrast", label: "High Contrast", group: "basic", swatches: ["#ffffff", "#0b5bd3", "#000000"] },
  { id: "graphite", label: "Graphite", group: "basic", swatches: ["#2b2d31", "#8a88f0", "#e7e8ea"] },
  { id: "dark", label: "Dark", group: "basic", swatches: ["#15151a", "#8482f5", "#e9e9f0"] },
  { id: "midnight", label: "Midnight", group: "basic", swatches: ["#07070b", "#6f6df0", "#e6e7ee"] },
  // ----- Fun -----
  { id: "aero", label: "Frutiger Aero", group: "fun", swatches: ["#7fd2ff", "#c9f5e6", "#0a8ed9"] },
  { id: "dusk", label: "Neon Dusk", group: "fun", swatches: ["#0f0c29", "#ff3df0", "#22e0ff"] },
  { id: "cottage", label: "Cottage Warm", group: "fun", swatches: ["#f4ecdd", "#7c9473", "#c8843c"] },
  { id: "vaporwave", label: "Vaporwave", group: "fun", swatches: ["#1a1130", "#ff6ad5", "#6be1ff"] },
  { id: "forest", label: "Deep Woods", group: "fun", swatches: ["#1c2a22", "#7fae6a", "#eef0e6"] },
  { id: "sunset", label: "Golden Hour", group: "fun", swatches: ["#f8c69a", "#e8743c", "#3a2a33"] },
  { id: "mono", label: "Brutalist", group: "fun", swatches: ["#ffffff", "#0040ff", "#000000"] },
  { id: "ocean", label: "Deep Sea", group: "fun", swatches: ["#06243a", "#2fd6d0", "#eaf7fb"] },
  { id: "sakura", label: "Cherry Blossom", group: "fun", swatches: ["#fdf4f7", "#d96a93", "#4a3a42"] },
  { id: "terminal", label: "Terminal", group: "fun", swatches: ["#050805", "#39ff14", "#5fff9f"] },
] as const;

export const PRESET_IDS: string[] = PRESETS.map((p) => p.id);

// Allow-list of fonts the custom designer may choose. The id is validated here;
// the client maps the id to a fixed font stack (user text is never used as CSS).
export const FONTS = [
  { id: "system", label: "System Sans" },
  { id: "rounded", label: "Rounded (Nunito)" },
  { id: "geometric", label: "Geometric (Poppins)" },
  { id: "humanist", label: "Humanist" },
  { id: "serif", label: "Serif (Georgia)" },
  { id: "mono", label: "Monospace" },
] as const;

export const FONT_IDS: string[] = FONTS.map((f) => f.id);

export const DEFAULT_THEME: Theme = { mode: "preset", preset: "light" };

const HEX_RE = /^#([0-9a-fA-F]{3}|[0-9a-fA-F]{6})$/;

export function isValidHex(v: unknown): v is string {
  return typeof v === "string" && HEX_RE.test(v.trim());
}

function sanitizeCustom(input: any): CustomTheme | undefined {
  if (!input || typeof input !== "object") return undefined;
  const hasAny =
    isValidHex(input.background) || isValidHex(input.fontColor) || isValidHex(input.sidebar) || FONT_IDS.includes(input.font);
  if (!hasAny) return undefined;
  return {
    background: isValidHex(input.background) ? String(input.background).trim() : "#ffffff",
    fontColor: isValidHex(input.fontColor) ? String(input.fontColor).trim() : "#1a1a1e",
    sidebar: isValidHex(input.sidebar) ? String(input.sidebar).trim() : "#ffffff",
    font: FONT_IDS.includes(input.font) ? String(input.font) : "system",
  };
}

/**
 * Turn untrusted input into a safe, normalized Theme. Never throws — invalid
 * input collapses to safe defaults. The saved `custom` palette is preserved
 * even when the active mode is a preset, so it stays re-selectable.
 */
export function sanitizeTheme(input: unknown): Theme {
  if (!input || typeof input !== "object") return { ...DEFAULT_THEME };
  const obj = input as Record<string, any>;

  const preset = PRESET_IDS.includes(obj.preset) ? String(obj.preset) : "light";
  const custom = sanitizeCustom(obj.custom);

  if (obj.mode === "custom") {
    if (!custom) return { mode: "preset", preset };
    return { mode: "custom", preset, custom };
  }
  return { mode: "preset", preset, custom };
}
