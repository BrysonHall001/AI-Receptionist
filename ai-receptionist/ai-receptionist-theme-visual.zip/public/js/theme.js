// Per-portal theming on the client.
//
// SECURITY: presets are applied by setting body[data-theme] to a charset-safe
// id only (real styling is author-written CSS). Custom values are applied with
// the CSSOM API (style.setProperty) using re-validated hex strings and a font
// id mapped to a hardcoded stack — never by building <style> text or innerHTML
// from user input, so there is no parsing context to break out of.
(function (global) {
  const App = global.App || (global.App = {});

  const FONT_STACKS = {
    system: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif',
    rounded: '"Nunito", "Segoe UI", system-ui, sans-serif',
    geometric: '"Poppins", "Century Gothic", system-ui, sans-serif',
    humanist: '"Segoe UI", Candara, "Trebuchet MS", system-ui, sans-serif',
    serif: 'Georgia, "Times New Roman", serif',
    mono: '"JetBrains Mono", ui-monospace, SFMono-Regular, Menlo, monospace',
  };

  const HEX_RE = /^#([0-9a-fA-F]{3}|[0-9a-fA-F]{6})$/;
  const isHex = (v) => typeof v === "string" && HEX_RE.test(v.trim());
  const DEFAULT_CUSTOM = { background: "#ffffff", fontColor: "#1a1a1e", sidebar: "#ffffff", font: "system" };

  // --- tiny color helpers (used only to DERIVE panel/topbar shades from the
  // already-validated custom background; output is always a clean #rrggbb). ---
  function hexToRgb(h) {
    h = h.replace("#", "");
    if (h.length === 3) h = h.split("").map((c) => c + c).join("");
    const n = parseInt(h, 16);
    return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
  }
  function toHex(r, g, b) {
    const f = (x) => ("0" + Math.max(0, Math.min(255, Math.round(x))).toString(16)).slice(-2);
    return "#" + f(r) + f(g) + f(b);
  }
  function mix(hex, target, amt) {
    const [r, g, b] = hexToRgb(hex);
    return toHex(r + (target - r) * amt, g + (target - g) * amt, b + (target - b) * amt);
  }
  function luminance(hex) {
    const [r, g, b] = hexToRgb(hex);
    return (0.2126 * r + 0.7152 * g + 0.0722 * b) / 255;
  }

  const CUSTOM_VARS = ["--bg", "--ink", "--sidebar-bg", "--font-ui", "--panel", "--panel-2", "--line", "--line-strong", "--row-hover", "--topbar-bg"];
  function clearCustom() {
    const s = document.body.style;
    CUSTOM_VARS.forEach((v) => s.removeProperty(v));
  }

  function applyTheme(theme) {
    const t = theme || {};
    if (t.mode === "custom" && t.custom) {
      const c = t.custom;
      document.body.dataset.theme = "custom";
      clearCustom();
      const s = document.body.style;
      if (isHex(c.fontColor)) s.setProperty("--ink", c.fontColor.trim());
      if (isHex(c.sidebar)) s.setProperty("--sidebar-bg", c.sidebar.trim());
      s.setProperty("--font-ui", FONT_STACKS[c.font] || FONT_STACKS.system);
      if (isHex(c.background)) {
        const bg = c.background.trim();
        s.setProperty("--bg", bg);
        // Derive content-panel + topbar shades from the background so custom
        // themes also theme the cards/widgets/topbar (not just the page).
        const light = luminance(bg) > 0.5;
        s.setProperty("--panel", light ? mix(bg, 255, 0.5) : mix(bg, 255, 0.1));
        s.setProperty("--panel-2", light ? mix(bg, 0, 0.04) : mix(bg, 255, 0.16));
        s.setProperty("--line", light ? mix(bg, 0, 0.1) : mix(bg, 255, 0.18));
        s.setProperty("--line-strong", light ? mix(bg, 0, 0.17) : mix(bg, 255, 0.27));
        s.setProperty("--row-hover", light ? mix(bg, 0, 0.04) : mix(bg, 255, 0.08));
        s.setProperty("--topbar-bg", light ? mix(bg, 255, 0.32) : mix(bg, 255, 0.07));
      }
      return;
    }
    clearCustom();
    const id = typeof t.preset === "string" && /^[a-z0-9_-]+$/.test(t.preset) ? t.preset : "light";
    document.body.dataset.theme = id;
  }

  function resetToDefault() {
    clearCustom();
    document.body.dataset.theme = "light";
  }

  async function loadAndApply() {
    try {
      const res = await App.portalApi("/api/theme");
      applyTheme(res.theme);
      return res;
    } catch (e) {
      resetToDefault();
      return null;
    }
  }

  // ---- Settings UI ----
  async function mountSettings(host) {
    const { el, esc, toast } = App.util;
    host.innerHTML = `<div class="cell-muted" style="padding:8px 0">Loading themes…</div>`;
    let data;
    try {
      data = await App.portalApi("/api/theme");
    } catch (e) {
      host.innerHTML = `<div class="cell-muted">${esc(e.message)}</div>`;
      return;
    }
    const presets = data.presets || [];
    const fonts = data.fonts || [];
    const current = data.theme || { mode: "preset", preset: "light" };

    const draft = {
      mode: current.mode === "custom" ? "custom" : "preset",
      preset: current.preset || "light",
      custom: current.custom ? { ...DEFAULT_CUSTOM, ...current.custom } : null,
    };

    function swatchHTML(swatches) {
      return (swatches || []).map((s) => `<span class="theme-swatch" style="background:${cssColor(s)}"></span>`).join("");
    }

    // The saved custom theme stays a selectable card (left as-is this pass).
    function savedCustomCard() {
      const c = el("button", "theme-card");
      c.type = "button";
      c.dataset.custom = "saved";
      const cu = draft.custom;
      c.innerHTML = `<div class="theme-swatches">${swatchHTML([cu.background, cu.sidebar, cu.fontColor])}</div><div class="theme-card-name">Your saved theme</div>`;
      c.onclick = () => { draft.mode = "custom"; applyTheme(draft); syncControls(); };
      return c;
    }

    // A dropdown for one preset group, with a live swatch preview beside it.
    function presetSelect(group) {
      const row = el("div", "theme-dd-row");
      const sel = document.createElement("select");
      sel.className = "input theme-dd";
      sel.dataset.group = group;
      const ph = document.createElement("option");
      ph.value = "";
      ph.textContent = group === "basic" ? "Choose a basic theme…" : "Choose a fun theme…";
      sel.appendChild(ph);
      presets.filter((p) => p.group === group).forEach((p) => {
        const o = document.createElement("option");
        o.value = p.id; o.textContent = p.label;
        sel.appendChild(o);
      });
      const sw = el("div", "theme-swatches theme-dd-swatches");
      sel.onchange = () => {
        const id = sel.value;
        if (!id) return;
        draft.mode = "preset"; draft.preset = id;
        applyTheme(draft); syncControls();
      };
      row.appendChild(sel); row.appendChild(sw);
      return row;
    }

    // Reflect the active selection across the dropdowns + cards.
    function syncControls() {
      host.querySelectorAll(".theme-dd").forEach((sel) => {
        const group = sel.dataset.group;
        const inGroup = draft.mode === "preset" && presets.some((p) => p.group === group && p.id === draft.preset);
        sel.value = inGroup ? draft.preset : "";
        const sw = sel.parentNode.querySelector(".theme-dd-swatches");
        const p = presets.find((x) => x.id === sel.value);
        if (sw) sw.innerHTML = p ? swatchHTML(p.swatches) : "";
      });
      host.querySelectorAll(".theme-card").forEach((node) => {
        const isCustomCard = node.dataset.custom === "saved" || node.dataset.custom === "editor";
        node.classList.toggle("selected", isCustomCard && draft.mode === "custom");
      });
    }

    function render() {
      host.innerHTML = "";
      const wrap = el("div", "theme-section");

      if (draft.custom) {
        wrap.appendChild(el("div", "theme-group-label", "Your saved theme"));
        const g0 = el("div", "theme-grid");
        g0.appendChild(savedCustomCard());
        wrap.appendChild(g0);
      }

      wrap.appendChild(el("div", "theme-group-label", "Basic"));
      wrap.appendChild(presetSelect("basic"));
      wrap.appendChild(el("div", "theme-group-label", "Fun"));
      wrap.appendChild(presetSelect("fun"));

      // Designer
      wrap.appendChild(el("div", "theme-group-label", "Design your own"));
      const cu = draft.custom || DEFAULT_CUSTOM;
      const designer = el("div", "theme-card theme-custom-card");
      designer.dataset.custom = "editor";
      const fontOpts = fonts.map((f) => `<option value="${esc(f.id)}"${f.id === cu.font ? " selected" : ""}>${esc(f.label)}</option>`).join("");
      designer.innerHTML = `
        <div class="theme-custom">
          <div class="theme-custom-row"><label>Background color</label><input type="color" id="th-bg" value="${cu.background}"></div>
          <div class="theme-custom-row"><label>Sidebar color</label><input type="color" id="th-side" value="${cu.sidebar}"></div>
          <div class="theme-custom-row"><label>Font color</label><input type="color" id="th-fg" value="${cu.fontColor}"></div>
          <div class="theme-custom-row"><label>Font</label><select id="th-font" class="input">${fontOpts}</select></div>
        </div>`;
      wrap.appendChild(designer);

      const saveBar = el("div");
      saveBar.style.marginTop = "14px";
      const saveBtn = el("button", "btn btn-primary btn-sm", "Save theme");
      saveBar.appendChild(saveBtn);
      wrap.appendChild(saveBar);
      host.appendChild(wrap);

      function readCustom() {
        draft.custom = {
          background: host.querySelector("#th-bg").value,
          sidebar: host.querySelector("#th-side").value,
          fontColor: host.querySelector("#th-fg").value,
          font: host.querySelector("#th-font").value,
        };
        draft.mode = "custom";
      }
      const onChange = () => { readCustom(); applyTheme(draft); syncControls(); };
      ["#th-bg", "#th-side", "#th-fg"].forEach((id) => { host.querySelector(id).oninput = onChange; });
      host.querySelector("#th-font").onchange = onChange;

      saveBtn.onclick = async () => {
        try {
          const payload = { mode: draft.mode, preset: draft.preset };
          if (draft.custom) payload.custom = draft.custom;
          const res = await App.portalApi("/api/theme", { method: "PATCH", body: JSON.stringify({ theme: payload }) });
          draft.mode = res.theme.mode;
          draft.preset = res.theme.preset || draft.preset;
          draft.custom = res.theme.custom ? { ...DEFAULT_CUSTOM, ...res.theme.custom } : draft.custom;
          applyTheme(res.theme);
          render();
          toast("Theme saved");
        } catch (e) {
          toast(e.message, true);
        }
      };

      syncControls();
    }

    render();
  }

  function cssColor(v) { return isHex(v) ? v : "transparent"; }

  App.theme = { applyTheme, resetToDefault, loadAndApply, mountSettings };
})(typeof window !== "undefined" ? window : globalThis);
