// Per-portal theming on the client.
//
// SECURITY: presets are applied by setting body[data-theme] to a charset-safe
// id only (real styling is author-written CSS). Custom values are applied with
// the CSSOM API (style.setProperty) using re-validated hex strings and a font
// id mapped to a hardcoded stack — never by building <style> text or innerHTML
// from user input, so there is no parsing context to break out of.
(function (global) {
  const App = global.App || (global.App = {});

  const FONT_STACKS = {
    system: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif',
    rounded: '"Nunito", "Segoe UI", system-ui, sans-serif',
    geometric: '"Poppins", "Century Gothic", system-ui, sans-serif',
    humanist: '"Segoe UI", Candara, "Trebuchet MS", system-ui, sans-serif',
    serif: 'Georgia, "Times New Roman", serif',
    mono: '"JetBrains Mono", ui-monospace, SFMono-Regular, Menlo, monospace',
  };

  const HEX_RE = /^#([0-9a-fA-F]{3}|[0-9a-fA-F]{6})$/;
  const isHex = (v) => typeof v === "string" && HEX_RE.test(v.trim());
  const DEFAULT_CUSTOM = { background: "#ffffff", fontColor: "#1a1a1e", sidebar: "#ffffff", font: "system" };

  function clearCustom() {
    const s = document.body.style;
    s.removeProperty("--bg");
    s.removeProperty("--ink");
    s.removeProperty("--sidebar-bg");
    s.removeProperty("--font-ui");
  }

  function applyTheme(theme) {
    const t = theme || {};
    if (t.mode === "custom" && t.custom) {
      const c = t.custom;
      document.body.dataset.theme = "custom";
      clearCustom();
      if (isHex(c.background)) document.body.style.setProperty("--bg", c.background.trim());
      if (isHex(c.fontColor)) document.body.style.setProperty("--ink", c.fontColor.trim());
      if (isHex(c.sidebar)) document.body.style.setProperty("--sidebar-bg", c.sidebar.trim());
      document.body.style.setProperty("--font-ui", FONT_STACKS[c.font] || FONT_STACKS.system);
      return;
    }
    clearCustom();
    const id = typeof t.preset === "string" && /^[a-z0-9_-]+$/.test(t.preset) ? t.preset : "light";
    document.body.dataset.theme = id;
  }

  function resetToDefault() {
    clearCustom();
    document.body.dataset.theme = "light";
  }

  async function loadAndApply() {
    try {
      const res = await App.portalApi("/api/theme");
      applyTheme(res.theme);
      return res;
    } catch (e) {
      resetToDefault();
      return null;
    }
  }

  // ---- Settings UI ----
  async function mountSettings(host) {
    const { el, esc, toast } = App.util;
    host.innerHTML = `<div class="cell-muted" style="padding:8px 0">Loading themes…</div>`;
    let data;
    try {
      data = await App.portalApi("/api/theme");
    } catch (e) {
      host.innerHTML = `<div class="cell-muted">${esc(e.message)}</div>`;
      return;
    }
    const presets = data.presets || [];
    const fonts = data.fonts || [];
    const current = data.theme || { mode: "preset", preset: "light" };

    // draft.custom is null until a custom design exists (saved or being edited).
    const draft = {
      mode: current.mode === "custom" ? "custom" : "preset",
      preset: current.preset || "light",
      custom: current.custom ? { ...DEFAULT_CUSTOM, ...current.custom } : null,
    };

    function presetCard(p) {
      const c = el("button", "theme-card");
      c.type = "button";
      c.dataset.preset = p.id;
      const sw = (p.swatches || []).map((s) => `<span class="theme-swatch" style="background:${cssColor(s)}"></span>`).join("");
      c.innerHTML = `<div class="theme-swatches">${sw}</div><div class="theme-card-name">${esc(p.label)}</div>`;
      c.onclick = () => { draft.mode = "preset"; draft.preset = p.id; applyTheme(draft); markSelection(); };
      return c;
    }

    // The saved custom theme, shown as a selectable tile (only when one exists).
    function savedCustomCard() {
      const c = el("button", "theme-card");
      c.type = "button";
      c.dataset.custom = "saved";
      const cu = draft.custom;
      const sw = [cu.background, cu.sidebar, cu.fontColor].map((s) => `<span class="theme-swatch" style="background:${cssColor(s)}"></span>`).join("");
      c.innerHTML = `<div class="theme-swatches">${sw}</div><div class="theme-card-name">Your saved theme</div>`;
      c.onclick = () => { draft.mode = "custom"; applyTheme(draft); markSelection(); };
      return c;
    }

    function markSelection() {
      host.querySelectorAll(".theme-card").forEach((node) => {
        let sel = false;
        if (node.dataset.custom === "saved" || node.dataset.custom === "editor") sel = draft.mode === "custom";
        else if (node.dataset.preset) sel = draft.mode === "preset" && draft.preset === node.dataset.preset;
        node.classList.toggle("selected", sel);
      });
    }

    function render() {
      host.innerHTML = "";
      const wrap = el("div", "theme-section");

      if (draft.custom) {
        wrap.appendChild(el("div", "theme-group-label", "Your saved theme"));
        const g0 = el("div", "theme-grid");
        g0.appendChild(savedCustomCard());
        wrap.appendChild(g0);
      }

      wrap.appendChild(el("div", "theme-group-label", "Basic"));
      const g1 = el("div", "theme-grid");
      presets.filter((p) => p.group === "basic").forEach((p) => g1.appendChild(presetCard(p)));
      wrap.appendChild(g1);

      wrap.appendChild(el("div", "theme-group-label", "Fun"));
      const g2 = el("div", "theme-grid");
      presets.filter((p) => p.group === "fun").forEach((p) => g2.appendChild(presetCard(p)));
      wrap.appendChild(g2);

      // Designer
      wrap.appendChild(el("div", "theme-group-label", "Design your own"));
      const cu = draft.custom || DEFAULT_CUSTOM;
      const designer = el("div", "theme-card theme-custom-card");
      designer.dataset.custom = "editor";
      const fontOpts = fonts.map((f) => `<option value="${esc(f.id)}"${f.id === cu.font ? " selected" : ""}>${esc(f.label)}</option>`).join("");
      designer.innerHTML = `
        <div class="theme-custom">
          <div class="theme-custom-row"><label>Background color</label><input type="color" id="th-bg" value="${cu.background}"></div>
          <div class="theme-custom-row"><label>Sidebar color</label><input type="color" id="th-side" value="${cu.sidebar}"></div>
          <div class="theme-custom-row"><label>Font color</label><input type="color" id="th-fg" value="${cu.fontColor}"></div>
          <div class="theme-custom-row"><label>Font</label><select id="th-font" class="input">${fontOpts}</select></div>
        </div>`;
      wrap.appendChild(designer);

      const saveBar = el("div");
      saveBar.style.marginTop = "14px";
      const saveBtn = el("button", "btn btn-primary btn-sm", "Save theme");
      saveBar.appendChild(saveBtn);
      wrap.appendChild(saveBar);
      host.appendChild(wrap);

      // wire designer inputs
      function readCustom() {
        draft.custom = {
          background: host.querySelector("#th-bg").value,
          sidebar: host.querySelector("#th-side").value,
          fontColor: host.querySelector("#th-fg").value,
          font: host.querySelector("#th-font").value,
        };
        draft.mode = "custom";
      }
      const onChange = () => { readCustom(); applyTheme(draft); markSelection(); };
      ["#th-bg", "#th-side", "#th-fg"].forEach((id) => { host.querySelector(id).oninput = onChange; });
      host.querySelector("#th-font").onchange = onChange;

      saveBtn.onclick = async () => {
        try {
          const payload = { mode: draft.mode, preset: draft.preset };
          if (draft.custom) payload.custom = draft.custom;
          const res = await App.portalApi("/api/theme", { method: "PATCH", body: JSON.stringify({ theme: payload }) });
          // reflect the server-sanitized result, then re-render so a freshly
          // designed custom theme appears as a selectable "saved theme" card.
          draft.mode = res.theme.mode;
          draft.preset = res.theme.preset || draft.preset;
          draft.custom = res.theme.custom ? { ...DEFAULT_CUSTOM, ...res.theme.custom } : draft.custom;
          applyTheme(res.theme);
          render();
          markSelection();
          toast("Theme saved");
        } catch (e) {
          toast(e.message, true);
        }
      };

      markSelection();
    }

    render();
  }

  function cssColor(v) { return isHex(v) ? v : "transparent"; }

  App.theme = { applyTheme, resetToDefault, loadAndApply, mountSettings };
})(typeof window !== "undefined" ? window : globalThis);
