(function (global) {
  const App = global.App || (global.App = {});
  const U = () => App.util;

  // ===================== pure engine =====================
  const SYSTEM = ["name", "phone", "email", "intent"];
  function valueOf(c, key) {
    if (key === "createdAt") return c.createdAt;
    if (key === "callCount") return c.callCount;
    if (SYSTEM.indexOf(key) >= 0) return c[key];
    return (c.customFields || {})[key];
  }
  function scalar(v) { if (v == null) return ""; if (Array.isArray(v)) return v.join(", "); if (typeof v === "boolean") return v ? "Yes" : "No"; return String(v); }
  function pad(n) { return n < 10 ? "0" + n : "" + n; }
  function bucketDate(iso, g) {
    const d = new Date(iso);
    if (isNaN(d.getTime())) return "(none)";
    if (g === "day") return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
    if (g === "year") return "" + d.getFullYear();
    if (g === "week") { const j = new Date(d.getFullYear(), 0, 1); const wk = Math.ceil(((d - j) / 86400000 + j.getDay() + 1) / 7); return `${d.getFullYear()}-W${pad(wk)}`; }
    return `${d.getFullYear()}-${pad(d.getMonth() + 1)}`;
  }
  function toDims(v, legacyDate) {
    if (Array.isArray(v)) return v.map((d) => (typeof d === "string" ? { key: d } : d)).filter((d) => d && d.key);
    if (typeof v === "string" && v) return [{ key: v, date: legacyDate }];
    return [];
  }
  function dimMeta(fields, dim) { const f = fields.find((x) => x.key === dim.key) || { key: dim.key, label: dim.key, type: "text" }; return { key: f.key, label: f.label, type: f.type, bucket: dim.date }; }
  function oneLabel(c, dm) {
    const v = valueOf(c, dm.key);
    if (dm.type === "date") return v ? bucketDate(v, dm.bucket || "month") : "(none)";
    if (v == null || v === "") return "(empty)";
    if (Array.isArray(v)) return v.length ? v.join(", ") : "(empty)";
    if (typeof v === "boolean") return v ? "Yes" : "No";
    return String(v);
  }
  function compoundLabel(c, dims, fields) { return dims.map((d) => oneLabel(c, dimMeta(fields, d))).join(" / "); }
  function measureValue(rows, m) {
    if (!m || m.op === "count") return rows.length;
    const nums = rows.map((r) => Number(valueOf(r, m.field))).filter((n) => !isNaN(n));
    if (m.op === "sum") return nums.reduce((a, b) => a + b, 0);
    if (m.op === "avg") return nums.length ? +(nums.reduce((a, b) => a + b, 0) / nums.length).toFixed(2) : 0;
    return rows.length;
  }
  function buildColumns(fields) { return fields.map((f) => ({ key: f.key, label: f.label, type: f.type === "percent" ? "number" : f.type, get: (r) => valueOf(r, f.key), text: (r) => scalar(valueOf(r, f.key)) })); }
  function groupRows(rows, dims, fields) { const map = new Map(); rows.forEach((r) => { const k = compoundLabel(r, dims, fields); if (!map.has(k)) map.set(k, []); map.get(k).push(r); }); return map; }
  function measureLabel(m, fields) { if (!m || m.op === "count") return "Count"; const f = fields.find((x) => x.key === m.field); return (m.op === "sum" ? "Sum of " : "Average of ") + (f ? f.label : m.field); }
  const CAP = 40;
  function aggregate(contacts, fields, w) {
    const cols = buildColumns(fields);
    const filtered = (App.table && App.table.pipeline) ? App.table.pipeline(contacts, cols, { rules: w.filters || [] }) : contacts.slice();
    const measure = w.measure || { op: "count" };
    if (w.type === "kpi") return { kind: "kpi", value: measureValue(filtered, measure) };
    const groupDims = toDims(w.groupBy, w.groupByDate);
    if (!groupDims.length) return { kind: "kpi", value: measureValue(filtered, measure) };
    const seriesDims = toDims(w.series, w.seriesDate);
    if (w.type === "stacked" || w.type === "heatmap") {
      const xMap = groupRows(filtered, groupDims, fields);
      let labels = Array.from(xMap.keys()).sort(); if (labels.length > CAP) labels = labels.slice(0, CAP);
      const seriesNames = seriesDims.length ? Array.from(new Set(filtered.map((r) => compoundLabel(r, seriesDims, fields)))).sort().slice(0, CAP) : ["All"];
      const series = seriesNames.map((sn) => ({ name: sn, data: labels.map((lab) => { const rows = (xMap.get(lab) || []).filter((r) => !seriesDims.length || compoundLabel(r, seriesDims, fields) === sn); return measureValue(rows, measure); }) }));
      if (w.type === "heatmap") { let max = 0; series.forEach((s) => s.data.forEach((v) => { if (v > max) max = v; })); return { kind: "heatmap", cols: labels, rows: seriesNames, series, max }; }
      return { kind: "stacked", labels, series, measureLabel: measureLabel(measure, fields) };
    }
    const map = groupRows(filtered, groupDims, fields);
    let entries = Array.from(map.entries()).map(([label, rows]) => [label, measureValue(rows, measure)]);
    const isDate = groupDims.length === 1 && dimMeta(fields, groupDims[0]).type === "date";
    entries.sort((a, b) => (isDate ? String(a[0]).localeCompare(String(b[0])) : b[1] - a[1]));
    if (entries.length > CAP) entries = entries.slice(0, CAP);
    return { kind: "series", labels: entries.map((e) => e[0]), data: entries.map((e) => e[1]), measureLabel: measureLabel(measure, fields) };
  }

  const PALETTE = ["#5b5bd6", "#3aa675", "#e0a23b", "#c2453f", "#3b82c4", "#8a4fc4", "#d2689a", "#4cae9e", "#9a8a3b", "#6b7280"];
  function baseOpts(stacked, hideScales) {
    const o = { responsive: true, maintainAspectRatio: false, plugins: { legend: { display: stacked || hideScales } } };
    if (!hideScales) o.scales = { x: { stacked: !!stacked, ticks: { maxRotation: 60, minRotation: 0 } }, y: { stacked: !!stacked, beginAtZero: true } };
    return o;
  }
  function renderWidgetBody(host, w, contacts, fields, charts) {
    const agg = aggregate(contacts, fields, w);
    host.innerHTML = "";
    const { el, esc } = U();
    if (agg.kind === "kpi") { const k = el("div", "kpi"); k.appendChild(el("div", "kpi-value", String(agg.value))); k.appendChild(el("div", "kpi-label", measureLabel(w.measure, fields))); host.appendChild(k); return; }
    if (agg.kind === "heatmap") {
      const table = el("table", "heatmap"); const thead = el("thead"); const htr = el("tr"); htr.appendChild(el("th", "", ""));
      agg.cols.forEach((c) => htr.appendChild(el("th", "", esc(c)))); thead.appendChild(htr); table.appendChild(thead);
      const tb = el("tbody");
      agg.rows.forEach((rowName, ri) => { const tr = el("tr"); tr.appendChild(el("th", "", esc(rowName)));
        agg.cols.forEach((_, ci) => { const v = agg.series[ri] ? agg.series[ri].data[ci] : 0; const inten = agg.max ? v / agg.max : 0; const td = el("td", "hm-cell", String(v)); td.style.background = `rgba(91,91,214,${0.08 + inten * 0.72})`; if (inten > 0.6) td.style.color = "#fff"; tr.appendChild(td); });
        tb.appendChild(tr); });
      table.appendChild(tb); const wrap = el("div", "heatmap-wrap"); wrap.appendChild(table); host.appendChild(wrap); return;
    }
    if (typeof Chart === "undefined") { host.innerHTML = `<p class="cell-muted">Charts need an internet connection.</p>`; return; }
    const canvas = document.createElement("canvas"); host.appendChild(canvas);
    let config;
    if (agg.kind === "stacked") config = { type: "bar", data: { labels: agg.labels, datasets: agg.series.map((s, i) => ({ label: s.name, data: s.data, backgroundColor: PALETTE[i % PALETTE.length] })) }, options: baseOpts(true) };
    else if (w.type === "pie") config = { type: "pie", data: { labels: agg.labels, datasets: [{ data: agg.data, backgroundColor: agg.labels.map((_, i) => PALETTE[i % PALETTE.length]) }] }, options: baseOpts(false, true) };
    else if (w.type === "line") config = { type: "line", data: { labels: agg.labels, datasets: [{ label: agg.measureLabel, data: agg.data, borderColor: PALETTE[0], backgroundColor: "rgba(91,91,214,0.15)", tension: 0.3, fill: true }] }, options: baseOpts(false) };
    else config = { type: "bar", data: { labels: agg.labels, datasets: [{ label: agg.measureLabel, data: agg.data, backgroundColor: PALETTE[0] }] }, options: baseOpts(false) };
    const ch = new Chart(canvas, config); if (charts) charts.push(ch);
  }

  function gridDims(w) {
    if (w.h == null) { const span = w.w && w.w <= 3 ? w.w : 1; return { x: w.x, y: w.y, w: span === 1 ? 4 : span === 2 ? 6 : 12, h: w.type === "kpi" ? 2 : 4 }; }
    return { x: w.x, y: w.y, w: w.w, h: w.h };
  }

  // ===================== view factory =====================
  function createView(host, opts) {
    opts = opts || {};
    const compact = !!opts.compact;
    const state = { dashboards: [], contacts: [], fields: [], reportFields: [], currentId: null, editMode: false, grid: null, charts: [] };
    const { el, esc, toast } = U();
    const api = { boot, refresh: boot };

    async function boot() {
      host.innerHTML = `<div class="card"><div class="skeleton">Loading…</div></div>`;
      try {
        const [d, c, f] = await Promise.all([App.portalApi("/api/dashboards"), App.portalApi("/api/contacts"), App.portalApi("/api/fields")]);
        state.dashboards = d; state.contacts = c; state.fields = f;
      } catch (e) { host.innerHTML = `<div class="card"><p class="cell-muted">${esc(e.message)}</p></div>`; return api; }
      state.reportFields = state.fields.concat([{ key: "createdAt", label: "Time Created", type: "date" }, { key: "callCount", label: "Number of calls", type: "number" }]);
      if (!state.currentId && state.dashboards.length) state.currentId = state.dashboards[0].id;
      paint();
      return api;
    }
    function current() { return state.dashboards.find((d) => d.id === state.currentId) || null; }
    function destroyCharts() { state.charts.forEach((c) => { try { c.destroy(); } catch (e) {} }); state.charts = []; }

    function paint() {
      destroyCharts();
      if (state.grid) { try { state.grid.destroy(false); } catch (e) {} state.grid = null; }
      host.innerHTML = "";
      const wrap = el("div", "fade-in");

      const bar = el("div", "reports-bar");
      const left = el("div", "reports-bar-left");
      if (state.dashboards.length) {
        const sel = el("select", "input reports-select");
        state.dashboards.forEach((d) => { const o = el("option", null, esc(d.name)); o.value = d.id; if (d.id === state.currentId) o.selected = true; sel.appendChild(o); });
        sel.onchange = () => { state.currentId = sel.value; state.editMode = false; paint(); };
        left.appendChild(sel);
      } else left.appendChild(el("span", "cell-muted", "No dashboards yet"));
      bar.appendChild(left);

      const right = el("div", "reports-bar-right");
      const newDash = el("button", "btn btn-ghost btn-sm", "+ New dashboard"); newDash.onclick = newDashboard; right.appendChild(newDash);
      if (current()) {
        const editBtn = el("button", "btn btn-sm " + (state.editMode ? "btn-primary" : "btn-ghost"), state.editMode ? "✓ Done" : "✎ Edit layout");
        editBtn.onclick = () => { state.editMode = !state.editMode; paint(); };
        const rename = el("button", "btn btn-ghost btn-sm", "Rename"); rename.onclick = renameDashboard;
        const del = el("button", "btn btn-ghost btn-sm", "Delete dashboard"); del.onclick = deleteCurrent;
        const addW = el("button", "btn btn-primary btn-sm", "+ Add widget"); addW.onclick = () => openEditor(null);
        right.appendChild(editBtn); right.appendChild(rename); right.appendChild(del); right.appendChild(addW);
      }
      bar.appendChild(right);
      wrap.appendChild(bar);

      const dash = current();
      if (!dash) { const e = el("div", "card"); e.innerHTML = `<div class="empty"><div class="empty-emoji">📊</div><h3>Create your first dashboard</h3><p>Build KPIs and charts from your contacts data.</p></div>`; wrap.appendChild(e); host.appendChild(wrap); return; }
      if (state.editMode) wrap.appendChild(el("div", "reports-hint", "Drag widgets to move them anywhere. Grab an edge or corner to resize. Changes save automatically."));
      const widgets = dash.widgets || [];
      if (!widgets.length) { const e = el("div", "card"); e.innerHTML = `<div class="empty"><div class="empty-emoji">➕</div><h3>No widgets yet</h3><p>Add a KPI or chart to this dashboard.</p></div>`; wrap.appendChild(e); host.appendChild(wrap); return; }

      if (typeof GridStack !== "undefined") renderGrid(wrap, dash, widgets);
      else renderFallback(wrap, dash, widgets);
      host.appendChild(wrap);

      if (state.grid) requestAnimationFrame(() => renderBodies(dash));
      else renderBodies(dash);
    }

    function cardInner(w, dash) {
      const card = el("div", "widget-card" + (w.type === "kpi" ? " widget-kpi" : ""));
      card.dataset.id = w.id;
      const head = el("div", "widget-head");
      const tw = el("div", "widget-title-wrap");
      if (state.editMode) tw.appendChild(el("span", "drag-handle", "⠿"));
      tw.appendChild(el("div", "widget-title", esc(w.title || "Untitled")));
      head.appendChild(tw);
      const actions = el("div", "widget-actions");
      const dup = el("button", "icon-btn", "⧉"); dup.title = "Duplicate"; dup.onclick = (e) => { e.stopPropagation(); openDuplicate(w); };
      const edit = el("button", "icon-btn", "✎"); edit.title = "Edit"; edit.onclick = (e) => { e.stopPropagation(); openEditor(w); };
      const del = el("button", "icon-btn", "×"); del.title = "Delete"; del.onclick = (e) => { e.stopPropagation(); removeWidget(w.id); };
      actions.appendChild(dup); actions.appendChild(edit); actions.appendChild(del);
      head.appendChild(actions);
      card.appendChild(head);
      card.appendChild(el("div", "widget-body"));
      return card;
    }

    function renderGrid(wrap, dash, widgets) {
      const gridEl = el("div", "grid-stack");
      widgets.forEach((w) => {
        const d = gridDims(w);
        const item = el("div", "grid-stack-item");
        item.setAttribute("gs-id", w.id);
        if (d.x != null) item.setAttribute("gs-x", d.x);
        if (d.y != null) item.setAttribute("gs-y", d.y);
        item.setAttribute("gs-w", d.w);
        item.setAttribute("gs-h", d.h);
        const content = el("div", "grid-stack-item-content");
        content.appendChild(cardInner(w, dash));
        item.appendChild(content);
        gridEl.appendChild(item);
      });
      wrap.appendChild(gridEl);
      state.grid = GridStack.init({ column: 12, cellHeight: compact ? 64 : 80, margin: 8, float: true, staticGrid: !state.editMode, handle: ".drag-handle" }, gridEl);
      state.grid.on("change", () => persistLayout(dash));
      state.grid.on("resizestop", () => { renderBodies(dash); persistLayout(dash); });
    }

    function renderFallback(wrap, dash, widgets) {
      const grid = el("div", "widget-grid");
      widgets.forEach((w) => { const card = cardInner(w, dash); const d = gridDims(w); card.style.gridColumn = "span " + Math.max(1, Math.round(d.w / 4)); grid.appendChild(card); });
      wrap.appendChild(grid);
    }

    function renderBodies(dash) {
      destroyCharts();
      U().$$(".widget-card", host).forEach((card) => {
        const w = (dash.widgets || []).find((x) => x.id === card.dataset.id);
        const body = card.querySelector(".widget-body");
        if (w && body) { try { renderWidgetBody(body, w, state.contacts, state.reportFields, state.charts); } catch (e) { body.innerHTML = `<p class="cell-muted">${esc(e.message)}</p>`; } }
      });
    }

    function persistLayout(dash) {
      if (!state.grid) return;
      const nodes = state.grid.save(false);
      const byId = {}; nodes.forEach((n) => { byId[n.id] = n; });
      (dash.widgets || []).forEach((w) => { const n = byId[w.id]; if (n) { w.x = n.x; w.y = n.y; w.w = n.w; w.h = n.h; } });
      dash.widgets.sort((a, b) => ((a.y || 0) - (b.y || 0)) || ((a.x || 0) - (b.x || 0)));
      persist(dash);
    }
    async function persist(dash) { try { await App.portalApi(`/api/dashboards/${dash.id}`, { method: "PATCH", body: JSON.stringify({ name: dash.name, widgets: dash.widgets }) }); } catch (e) { toast(e.message, true); } }

    async function newDashboard() {
      const name = prompt("Dashboard name:", "New dashboard"); if (!name || !name.trim()) return;
      try { const d = await App.portalApi("/api/dashboards", { method: "POST", body: JSON.stringify({ name: name.trim() }) }); state.dashboards.push(d); state.currentId = d.id; paint(); toast("Dashboard created"); } catch (e) { toast(e.message, true); }
    }
    async function renameDashboard() { const d = current(); if (!d) return; const name = prompt("Rename dashboard:", d.name); if (!name || !name.trim()) return; d.name = name.trim(); await persist(d); paint(); }
    async function deleteCurrent() { const d = current(); if (!d) return; if (!confirm(`Delete dashboard “${d.name}” and its widgets?`)) return; try { await App.portalApi(`/api/dashboards/${d.id}`, { method: "DELETE" }); state.dashboards = state.dashboards.filter((x) => x.id !== d.id); state.currentId = state.dashboards.length ? state.dashboards[0].id : null; state.editMode = false; paint(); toast("Dashboard deleted"); } catch (e) { toast(e.message, true); } }
    function removeWidget(wid) { const d = current(); if (!d) return; if (!confirm("Remove this widget?")) return; d.widgets = (d.widgets || []).filter((w) => w.id !== wid); persist(d); paint(); }

    function openDuplicate(w) {
      const inner = el("div");
      inner.innerHTML = `<div class="modal-head"><h2>Duplicate widget</h2><button class="icon-btn" id="d-close">&times;</button></div>
        <div class="modal-body"><label class="field-label">Copy “${esc(w.title || "Untitled")}” to dashboard:</label>
        <select id="d-target" class="input">${state.dashboards.map((d) => `<option value="${d.id}"${d.id === state.currentId ? " selected" : ""}>${esc(d.name)}</option>`).join("")}</select>
        <button id="d-go" class="btn btn-primary btn-block" style="margin-top:14px">Duplicate</button></div>`;
      const overlay = modal(inner);
      inner.querySelector("#d-close").onclick = () => overlay.remove();
      inner.querySelector("#d-go").onclick = async () => {
        const target = state.dashboards.find((d) => d.id === inner.querySelector("#d-target").value); if (!target) return;
        const copy = JSON.parse(JSON.stringify(w)); copy.id = "w" + Date.now() + Math.floor(Math.random() * 999); copy.title = (w.title || "Untitled") + " (copy)"; copy.x = undefined; copy.y = undefined;
        target.widgets = target.widgets || []; target.widgets.push(copy); await persist(target); overlay.remove();
        toast(target.id === state.currentId ? "Widget duplicated" : `Copied to “${target.name}”`);
        if (target.id === state.currentId) paint();
      };
    }

    function dimListEditor(host2, fields, initialDims, onChange) {
      const rows = []; const list = el("div", "dim-list"); host2.appendChild(list);
      const addBtn = el("button", "btn btn-ghost btn-sm", "+ Add dimension"); host2.appendChild(addBtn);
      function addRow(initial) {
        const row = el("div", "dim-row");
        const sel = el("select", "input"); const blank = el("option", null, "— select —"); blank.value = ""; sel.appendChild(blank);
        fields.forEach((f) => { const o = el("option", null, f.label); o.value = f.key; sel.appendChild(o); });
        const dateSel = el("select", "input"); [["day", "By day"], ["week", "By week"], ["month", "By month"], ["year", "By year"]].forEach(([v, l]) => { const o = el("option", null, l); o.value = v; if (v === "month") o.selected = true; dateSel.appendChild(o); }); dateSel.style.display = "none";
        const rm = el("button", "icon-btn", "×");
        const entry = { get: () => { if (!sel.value) return null; const f = fields.find((x) => x.key === sel.value); return f && f.type === "date" ? { key: sel.value, date: dateSel.value } : { key: sel.value }; } };
        function syncDate() { const f = fields.find((x) => x.key === sel.value); dateSel.style.display = f && f.type === "date" ? "" : "none"; }
        sel.onchange = () => { syncDate(); onChange && onChange(); }; dateSel.onchange = () => onChange && onChange();
        rm.onclick = () => { list.removeChild(row); const i = rows.indexOf(entry); if (i >= 0) rows.splice(i, 1); onChange && onChange(); };
        if (initial) { sel.value = initial.key; if (initial.date) dateSel.value = initial.date; } syncDate();
        row.appendChild(sel); row.appendChild(dateSel); row.appendChild(rm); rows.push(entry); list.appendChild(row);
      }
      (initialDims && initialDims.length ? initialDims : []).forEach(addRow);
      addBtn.onclick = () => { addRow(null); onChange && onChange(); };
      return { getDims: () => rows.map((r) => r.get()).filter(Boolean) };
    }

    function openEditor(existing) {
      const dash = current(); if (!dash) return;
      const w = existing ? JSON.parse(JSON.stringify(existing)) : { id: "w" + Date.now(), title: "", type: "kpi", measure: { op: "count" }, groupBy: [], series: [], filters: [] };
      if (!w.measure) w.measure = { op: "count" };
      const numericFields = state.reportFields.filter((f) => f.type === "number" || f.type === "percent");
      let previewCharts = [];
      const inner = el("div");
      inner.innerHTML = `<div class="modal-head"><h2>${existing ? "Edit widget" : "Add widget"}</h2><button class="icon-btn" id="w-close">&times;</button></div>
        <div class="modal-body">
          <label class="field-label">Title</label><input id="w-title" class="input" value="${esc(w.title || "")}" placeholder="e.g. Leads by tier" />
          <label class="field-label">Type</label>
          <select id="w-type" class="input"><option value="kpi">KPI (single number)</option><option value="bar">Bar chart</option><option value="stacked">Stacked bar</option><option value="line">Line chart</option><option value="pie">Pie chart</option><option value="heatmap">Heat map</option></select>
          <label class="field-label">Measure</label>
          <div class="w-row"><select id="w-mop" class="input"><option value="count">Count of records</option><option value="sum">Sum of…</option><option value="avg">Average of…</option></select>
          <select id="w-mfield" class="input" style="display:none">${numericFields.map((f) => `<option value="${esc(f.key)}">${esc(f.label)}</option>`).join("")}</select></div>
          <div id="w-group-wrap"><label class="field-label">Group by</label><div id="w-group"></div></div>
          <div id="w-series-wrap" style="display:none"><label class="field-label" id="w-series-label">Stack by</label><div id="w-series"></div></div>
          <label class="field-label">Filters</label><div id="w-filters"></div>
          <div class="w-preview-label">Preview</div><div id="w-preview" class="w-preview"></div>
          <button id="w-save" class="btn btn-primary btn-block">${existing ? "Save widget" : "Add widget"}</button>
        </div>`;
      const overlay = modal(inner); const $ = (s) => inner.querySelector(s);
      $("#w-close").onclick = () => overlay.remove();
      $("#w-type").value = w.type; $("#w-mop").value = w.measure.op; if (w.measure.field) $("#w-mfield").value = w.measure.field;
      const groupEd = dimListEditor($("#w-group"), state.reportFields, toDims(w.groupBy, w.groupByDate), () => preview());
      const seriesEd = dimListEditor($("#w-series"), state.reportFields, toDims(w.series, w.seriesDate), () => preview());
      $("#w-filters").appendChild(App.table.ruleEditor(buildColumns(state.reportFields), state.contacts, w.filters, () => preview()));
      function sync() { const t = $("#w-type").value; $("#w-mfield").style.display = $("#w-mop").value === "count" ? "none" : "block"; $("#w-group-wrap").style.display = t === "kpi" ? "none" : "block"; const ns = t === "stacked" || t === "heatmap"; $("#w-series-wrap").style.display = ns ? "block" : "none"; $("#w-series-label").textContent = t === "heatmap" ? "Rows (second dimension)" : "Stack by"; preview(); }
      function collect() { const t = $("#w-type").value; const mop = $("#w-mop").value; return { id: w.id, title: $("#w-title").value.trim() || "Untitled", type: t, measure: mop === "count" ? { op: "count" } : { op: mop, field: $("#w-mfield").value }, groupBy: t === "kpi" ? [] : groupEd.getDims(), series: (t === "stacked" || t === "heatmap") ? seriesEd.getDims() : [], filters: w.filters, x: w.x, y: w.y, w: w.w, h: w.h }; }
      function preview() { previewCharts.forEach((c) => { try { c.destroy(); } catch (e) {} }); previewCharts = []; try { renderWidgetBody($("#w-preview"), collect(), state.contacts, state.reportFields, previewCharts); } catch (e) { $("#w-preview").innerHTML = `<p class="cell-muted">${esc(e.message)}</p>`; } }
      ["#w-type", "#w-mop", "#w-mfield", "#w-title"].forEach((s) => { $(s).addEventListener("change", sync); $(s).addEventListener("input", preview); });
      sync();
      $("#w-save").onclick = async () => { const widget = collect(); const d = current(); d.widgets = d.widgets || []; const idx = d.widgets.findIndex((x) => x.id === widget.id); if (idx >= 0) d.widgets[idx] = widget; else d.widgets.push(widget); await persist(d); overlay.remove(); paint(); toast(existing ? "Widget saved" : "Widget added"); };
    }

    function modal(inner) { const overlay = el("div", "modal-overlay"); const box = el("div", "modal modal-wide"); box.appendChild(inner); overlay.appendChild(box); overlay.onclick = (e) => { if (e.target === overlay) overlay.remove(); }; document.body.appendChild(overlay); return overlay; }

    return api;
  }

  App.reports = {
    render: (host) => createView(host, {}).boot(),
    mountHome: (host) => createView(host, { compact: true }).boot(),
    aggregate, valueOf, bucketDate, measureValue,
  };
})(typeof window !== "undefined" ? window : globalThis);
