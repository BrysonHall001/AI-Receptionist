// Per-portal theming on the client.
//
// SECURITY: presets are applied by setting body[data-theme] to a known id only
// (real styling is author-written CSS). Custom values are applied with the
// CSSOM API (style.setProperty) using a re-validated hex string and a font id
// mapped to a hardcoded stack — never by building <style> text or innerHTML
// from user input, so there is no parsing context to break out of.
(function (global) {
  const App = global.App || (global.App = {});

  // id -> fixed font stack. The user's choice is an id from this map; their
  // text is never used directly as a CSS value.
  const FONT_STACKS = {
    system: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif',
    rounded: '"Nunito", "Segoe UI", system-ui, sans-serif',
    geometric: '"Poppins", "Century Gothic", system-ui, sans-serif',
    humanist: '"Segoe UI", Candara, "Trebuchet MS", system-ui, sans-serif',
    serif: 'Georgia, "Times New Roman", serif',
    mono: '"JetBrains Mono", ui-monospace, SFMono-Regular, Menlo, monospace',
  };

  const KNOWN_PRESETS = ["light", "dark", "neutral", "aero", "dusk", "cottage"];
  const HEX_RE = /^#([0-9a-fA-F]{3}|[0-9a-fA-F]{6})$/;
  const isHex = (v) => typeof v === "string" && HEX_RE.test(v.trim());

  function clearCustom() {
    const s = document.body.style;
    s.removeProperty("--bg");
    s.removeProperty("--ink");
    s.removeProperty("--font-ui");
  }

  // Apply a theme object: { mode:"preset", preset } or { mode:"custom", custom }.
  function applyTheme(theme) {
    const t = theme || {};
    if (t.mode === "custom" && t.custom) {
      const c = t.custom;
      document.body.dataset.theme = "custom";
      clearCustom();
      if (isHex(c.background)) document.body.style.setProperty("--bg", c.background.trim());
      if (isHex(c.fontColor)) document.body.style.setProperty("--ink", c.fontColor.trim());
      const stack = FONT_STACKS[c.font] || FONT_STACKS.system;
      document.body.style.setProperty("--font-ui", stack);
      return;
    }
    // preset
    clearCustom();
    const id = KNOWN_PRESETS.indexOf(t.preset) >= 0 ? t.preset : "light";
    document.body.dataset.theme = id;
  }

  function resetToDefault() {
    clearCustom();
    document.body.dataset.theme = "light";
  }

  // Fetch the current portal's theme and apply it. Tenant scoping is handled by
  // App.portalApi (it appends the viewed portal for super admins).
  let lastKey = null;
  async function loadAndApply() {
    try {
      const res = await App.portalApi("/api/theme");
      applyTheme(res.theme);
      return res;
    } catch (e) {
      resetToDefault();
      return null;
    }
  }

  // ---- Settings UI ----
  async function mountSettings(host) {
    const { el, esc, toast } = App.util;
    host.innerHTML = `<div class="cell-muted" style="padding:8px 0">Loading themes…</div>`;
    let data;
    try {
      data = await App.portalApi("/api/theme");
    } catch (e) {
      host.innerHTML = `<div class="cell-muted">${esc(e.message)}</div>`;
      return;
    }
    const presets = data.presets || [];
    const fonts = data.fonts || [];
    const current = data.theme || { mode: "preset", preset: "light" };

    // Draft state the user edits; applied live, saved on Save.
    const draft = current.mode === "custom"
      ? { mode: "custom", custom: { ...current.custom } }
      : { mode: "preset", preset: current.preset || "light" };

    host.innerHTML = "";
    const basics = presets.filter((p) => p.group === "basic");
    const fun = presets.filter((p) => p.group === "fun");

    function card(p) {
      const c = el("button", "theme-card" + (draft.mode === "preset" && draft.preset === p.id ? " selected" : ""));
      c.type = "button";
      c.dataset.preset = p.id;
      const sw = (p.swatches || []).map((s) => `<span class="theme-swatch" style="background:${cssColor(s)}"></span>`).join("");
      c.innerHTML = `<div class="theme-swatches">${sw}</div><div class="theme-card-name">${esc(p.label)}</div>`;
      c.onclick = () => {
        draft.mode = "preset";
        draft.preset = p.id;
        applyTheme(draft); // live preview
        markSelection();
      };
      return c;
    }

    const wrap = el("div", "theme-section");
    wrap.appendChild(el("div", "theme-group-label", "Basic"));
    const g1 = el("div", "theme-grid");
    basics.forEach((p) => g1.appendChild(card(p)));
    wrap.appendChild(g1);
    wrap.appendChild(el("div", "theme-group-label", "Fun"));
    const g2 = el("div", "theme-grid");
    fun.forEach((p) => g2.appendChild(card(p)));
    wrap.appendChild(g2);

    // Custom designer
    wrap.appendChild(el("div", "theme-group-label", "Design your own"));
    const customCard = el("div", "theme-card" + (draft.mode === "custom" ? " selected" : ""));
    customCard.dataset.custom = "1";
    const cust = draft.mode === "custom" ? draft.custom : { background: "#ffffff", fontColor: "#1a1a1e", font: "system" };
    const fontOpts = fonts.map((f) => `<option value="${esc(f.id)}"${f.id === cust.font ? " selected" : ""}>${esc(f.label)}</option>`).join("");
    customCard.innerHTML = `
      <div class="theme-custom">
        <div class="theme-custom-row"><label>Background color</label><input type="color" id="th-bg" value="${cust.background}"></div>
        <div class="theme-custom-row"><label>Font color</label><input type="color" id="th-fg" value="${cust.fontColor}"></div>
        <div class="theme-custom-row"><label>Font</label><select id="th-font" class="input">${fontOpts}</select></div>
      </div>`;
    wrap.appendChild(customCard);

    const saveBar = el("div");
    saveBar.style.marginTop = "14px";
    const saveBtn = el("button", "btn btn-primary btn-sm", "Save theme");
    saveBar.appendChild(saveBtn);
    wrap.appendChild(saveBar);
    host.appendChild(wrap);

    function markSelection() {
      host.querySelectorAll(".theme-card").forEach((node) => {
        const isSel = node.dataset.custom ? draft.mode === "custom" : (draft.mode === "preset" && draft.preset === node.dataset.preset);
        node.classList.toggle("selected", !!isSel);
      });
    }

    function readCustom() {
      draft.mode = "custom";
      draft.custom = {
        background: host.querySelector("#th-bg").value,
        fontColor: host.querySelector("#th-fg").value,
        font: host.querySelector("#th-font").value,
      };
    }
    const onCustomChange = () => { readCustom(); applyTheme(draft); markSelection(); };
    host.querySelector("#th-bg").oninput = onCustomChange;
    host.querySelector("#th-fg").oninput = onCustomChange;
    host.querySelector("#th-font").onchange = onCustomChange;

    saveBtn.onclick = async () => {
      try {
        const res = await App.portalApi("/api/theme", { method: "PATCH", body: JSON.stringify({ theme: draft }) });
        applyTheme(res.theme); // apply the server-sanitized version
        toast("Theme saved");
      } catch (e) {
        toast(e.message, true);
      }
    };
  }

  // Only emit a safe color into the swatch preview inline style.
  function cssColor(v) {
    return isHex(v) ? v : "transparent";
  }

  App.theme = { applyTheme, resetToDefault, loadAndApply, mountSettings };
})(typeof window !== "undefined" ? window : globalThis);
