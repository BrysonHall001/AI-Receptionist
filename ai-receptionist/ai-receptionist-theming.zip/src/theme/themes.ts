// Central theme definitions + the server-side sanitizer.
//
// SECURITY: nothing here ever turns user input into raw CSS. Presets are
// referenced by id only (the actual styling is author-written CSS keyed by a
// data-theme attribute on the client). Custom values are strictly validated:
// colors must be #rgb/#rrggbb hex, and the font must be one of a fixed set of
// ids. Anything else is rejected and replaced with the safe default, so only
// known-good values can ever be stored.

export type ThemeMode = "preset" | "custom";

export interface CustomTheme {
  background: string; // hex
  fontColor: string; // hex
  font: string; // a FONT id from the allow-list
}

export interface Theme {
  mode: ThemeMode;
  preset?: string; // a PRESET id
  custom?: CustomTheme;
}

// The 6 shipped presets. Adding a 7th = add an entry here AND a matching
// `body[data-theme="<id>"]` block in public/styles.css. Nothing else to wire.
export const PRESETS = [
  { id: "light", label: "Clean Light", group: "basic", swatches: ["#fbfbfa", "#5b59d6", "#1a1a1e"] },
  { id: "dark", label: "Dark", group: "basic", swatches: ["#15151a", "#8482f5", "#e9e9f0"] },
  { id: "neutral", label: "Neutral Pro", group: "basic", swatches: ["#f5f6f7", "#2f6f8f", "#22282e"] },
  { id: "aero", label: "Frutiger Aero", group: "fun", swatches: ["#7fd2ff", "#c9f5e6", "#0a8ed9"] },
  { id: "dusk", label: "Neon Dusk", group: "fun", swatches: ["#0f0c29", "#ff3df0", "#22e0ff"] },
  { id: "cottage", label: "Cottage Warm", group: "fun", swatches: ["#f4ecdd", "#7c9473", "#c8843c"] },
] as const;

export const PRESET_IDS: string[] = PRESETS.map((p) => p.id);

// Allow-list of fonts the custom designer may choose. The id is validated here;
// the client maps the id to a fixed font stack (the user's text is never used
// directly as a CSS value).
export const FONTS = [
  { id: "system", label: "System Sans" },
  { id: "rounded", label: "Rounded (Nunito)" },
  { id: "geometric", label: "Geometric (Poppins)" },
  { id: "humanist", label: "Humanist" },
  { id: "serif", label: "Serif (Georgia)" },
  { id: "mono", label: "Monospace" },
] as const;

export const FONT_IDS: string[] = FONTS.map((f) => f.id);

export const DEFAULT_THEME: Theme = { mode: "preset", preset: "light" };

const HEX_RE = /^#([0-9a-fA-F]{3}|[0-9a-fA-F]{6})$/;

export function isValidHex(v: unknown): v is string {
  return typeof v === "string" && HEX_RE.test(v.trim());
}

/**
 * Turn untrusted input into a safe, normalized Theme. Never throws — invalid
 * input collapses to the default so a malformed request can't store anything
 * dangerous (defense in depth alongside the route).
 */
export function sanitizeTheme(input: unknown): Theme {
  if (!input || typeof input !== "object") return { ...DEFAULT_THEME };
  const obj = input as Record<string, any>;

  if (obj.mode === "custom") {
    const c = (obj.custom ?? {}) as Record<string, any>;
    const background = isValidHex(c.background) ? String(c.background).trim() : "#ffffff";
    const fontColor = isValidHex(c.fontColor) ? String(c.fontColor).trim() : "#1a1a1e";
    const font = FONT_IDS.includes(c.font) ? String(c.font) : "system";
    return { mode: "custom", custom: { background, fontColor, font } };
  }

  // Default path: a preset.
  const preset = PRESET_IDS.includes(obj.preset) ? String(obj.preset) : "light";
  return { mode: "preset", preset };
}
