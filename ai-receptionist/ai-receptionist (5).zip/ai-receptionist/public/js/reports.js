(function (global) {
  const App = global.App || (global.App = {});
  const U = () => App.util;

  // ---------------- aggregation engine (pure) ----------------
  const SYSTEM = ["name", "phone", "email", "intent"];
  function valueOf(c, key) {
    if (key === "createdAt") return c.createdAt;
    if (key === "callCount") return c.callCount;
    if (SYSTEM.indexOf(key) >= 0) return c[key];
    return (c.customFields || {})[key];
  }
  function scalar(v) {
    if (v == null) return "";
    if (Array.isArray(v)) return v.join(", ");
    if (typeof v === "boolean") return v ? "Yes" : "No";
    return String(v);
  }
  function pad(n) { return n < 10 ? "0" + n : "" + n; }
  function bucketDate(iso, g) {
    const d = new Date(iso);
    if (isNaN(d.getTime())) return "(none)";
    if (g === "day") return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
    if (g === "year") return "" + d.getFullYear();
    if (g === "week") { const onejan = new Date(d.getFullYear(), 0, 1); const wk = Math.ceil(((d - onejan) / 86400000 + onejan.getDay() + 1) / 7); return `${d.getFullYear()}-W${pad(wk)}`; }
    return `${d.getFullYear()}-${pad(d.getMonth() + 1)}`; // month
  }
  function dimLabel(c, dim) {
    const v = valueOf(c, dim.key);
    if (dim.type === "date") return v ? bucketDate(v, dim.bucket || "month") : "(none)";
    if (v == null || v === "") return "(empty)";
    if (Array.isArray(v)) return v.length ? v.join(", ") : "(empty)";
    if (typeof v === "boolean") return v ? "Yes" : "No";
    return String(v);
  }
  function measureValue(rows, measure) {
    if (!measure || measure.op === "count") return rows.length;
    const nums = rows.map((r) => Number(valueOf(r, measure.field))).filter((n) => !isNaN(n));
    if (measure.op === "sum") return nums.reduce((a, b) => a + b, 0);
    if (measure.op === "avg") return nums.length ? +(nums.reduce((a, b) => a + b, 0) / nums.length).toFixed(2) : 0;
    return rows.length;
  }
  function buildColumns(fields) {
    return fields.map((f) => ({ key: f.key, label: f.label, type: f.type === "percent" ? "number" : f.type, get: (r) => valueOf(r, f.key), text: (r) => scalar(valueOf(r, f.key)) }));
  }
  function groupBy(rows, dim) {
    const map = new Map();
    rows.forEach((r) => { const k = dimLabel(r, dim); if (!map.has(k)) map.set(k, []); map.get(k).push(r); });
    return map;
  }
  const CAP = 30;
  function aggregate(contacts, fields, w) {
    const cols = buildColumns(fields);
    const filtered = (App.table && App.table.pipeline) ? App.table.pipeline(contacts, cols, { rules: w.filters || [] }) : contacts.slice();
    const measure = w.measure || { op: "count" };
    if (w.type === "kpi") return { kind: "kpi", value: measureValue(filtered, measure) };

    const primary = w.groupBy ? fieldDim(fields, w.groupBy, w.groupByDate) : null;
    if (!primary) return { kind: "kpi", value: measureValue(filtered, measure) };

    if (w.type === "stacked" || w.type === "heatmap") {
      const sec = w.series ? fieldDim(fields, w.series, w.seriesDate) : null;
      const xMap = groupBy(filtered, primary);
      let labels = Array.from(xMap.keys()).sort();
      if (labels.length > CAP) labels = labels.slice(0, CAP);
      const seriesNames = sec ? uniqueSorted(filtered.map((r) => dimLabel(r, sec))).slice(0, CAP) : ["All"];
      const series = seriesNames.map((sn) => ({
        name: sn,
        data: labels.map((lab) => {
          const rows = (xMap.get(lab) || []).filter((r) => !sec || dimLabel(r, sec) === sn);
          return measureValue(rows, measure);
        }),
      }));
      if (w.type === "heatmap") {
        let max = 0; series.forEach((s) => s.data.forEach((v) => { if (v > max) max = v; }));
        return { kind: "heatmap", cols: labels, rows: seriesNames, series, max };
      }
      return { kind: "stacked", labels, series, measureLabel: measureLabel(measure, fields) };
    }

    // bar / line / pie -> single series
    const map = groupBy(filtered, primary);
    let entries = Array.from(map.entries()).map(([label, rows]) => [label, measureValue(rows, measure)]);
    entries.sort((a, b) => (primary.type === "date" ? String(a[0]).localeCompare(String(b[0])) : b[1] - a[1]));
    if (entries.length > CAP) entries = entries.slice(0, CAP);
    return { kind: "series", labels: entries.map((e) => e[0]), data: entries.map((e) => e[1]), measureLabel: measureLabel(measure, fields) };
  }
  function uniqueSorted(arr) { return Array.from(new Set(arr)).sort(); }
  function fieldDim(fields, key, bucket) {
    const f = fields.find((x) => x.key === key) || { key, label: key, type: "text" };
    return { key: f.key, label: f.label, type: f.type, bucket };
  }
  function measureLabel(m, fields) {
    if (!m || m.op === "count") return "Count";
    const f = fields.find((x) => x.key === m.field);
    const fl = f ? f.label : m.field;
    return (m.op === "sum" ? "Sum of " : "Average of ") + fl;
  }

  // ---------------- rendering ----------------
  const PALETTE = ["#5b5bd6", "#3aa675", "#e0a23b", "#c2453f", "#3b82c4", "#8a4fc4", "#d2689a", "#4cae9e", "#9a8a3b", "#6b7280"];
  let activeCharts = [];
  function destroyCharts() { activeCharts.forEach((c) => { try { c.destroy(); } catch (e) {} }); activeCharts = []; }

  function renderWidgetBody(host, w, contacts, fields) {
    const agg = aggregate(contacts, fields, w);
    host.innerHTML = "";
    if (agg.kind === "kpi") {
      const k = U().el("div", "kpi");
      k.appendChild(U().el("div", "kpi-value", String(agg.value)));
      k.appendChild(U().el("div", "kpi-label", measureLabel(w.measure, fields)));
      host.appendChild(k);
      return;
    }
    if (agg.kind === "heatmap") { renderHeatmap(host, agg); return; }
    if (typeof Chart === "undefined") { host.innerHTML = `<p class="cell-muted">Charts need an internet connection.</p>`; return; }

    const canvas = document.createElement("canvas");
    host.appendChild(canvas);
    let config;
    if (agg.kind === "stacked") {
      config = { type: "bar", data: { labels: agg.labels, datasets: agg.series.map((s, i) => ({ label: s.name, data: s.data, backgroundColor: PALETTE[i % PALETTE.length] })) },
        options: baseOpts(true) };
    } else if (w.type === "pie") {
      config = { type: "pie", data: { labels: agg.labels, datasets: [{ data: agg.data, backgroundColor: agg.labels.map((_, i) => PALETTE[i % PALETTE.length]) }] }, options: baseOpts(false, true) };
    } else if (w.type === "line") {
      config = { type: "line", data: { labels: agg.labels, datasets: [{ label: agg.measureLabel, data: agg.data, borderColor: PALETTE[0], backgroundColor: "rgba(91,91,214,0.15)", tension: 0.3, fill: true }] }, options: baseOpts(false) };
    } else {
      config = { type: "bar", data: { labels: agg.labels, datasets: [{ label: agg.measureLabel, data: agg.data, backgroundColor: PALETTE[0] }] }, options: baseOpts(false) };
    }
    activeCharts.push(new Chart(canvas, config));
  }
  function baseOpts(stacked, hideScales) {
    const o = { responsive: true, maintainAspectRatio: false, plugins: { legend: { display: stacked || hideScales } } };
    if (!hideScales) o.scales = { x: { stacked: !!stacked, ticks: { maxRotation: 60, minRotation: 0 } }, y: { stacked: !!stacked, beginAtZero: true } };
    return o;
  }
  function renderHeatmap(host, agg) {
    const table = U().el("table", "heatmap");
    const thead = U().el("thead"); const htr = U().el("tr"); htr.appendChild(U().el("th", "", ""));
    agg.cols.forEach((c) => htr.appendChild(U().el("th", "", U().esc(c)))); thead.appendChild(htr); table.appendChild(thead);
    const tb = U().el("tbody");
    agg.rows.forEach((rowName, ri) => {
      const tr = U().el("tr"); tr.appendChild(U().el("th", "", U().esc(rowName)));
      agg.cols.forEach((_, ci) => {
        const v = agg.series[ri] ? agg.series[ri].data[ci] : 0;
        const intensity = agg.max ? v / agg.max : 0;
        const td = U().el("td", "hm-cell", String(v));
        td.style.background = `rgba(91,91,214,${0.08 + intensity * 0.72})`;
        if (intensity > 0.6) td.style.color = "#fff";
        tr.appendChild(td);
      });
      tb.appendChild(tr);
    });
    table.appendChild(tb);
    const wrap = U().el("div", "heatmap-wrap"); wrap.appendChild(table); host.appendChild(wrap);
  }

  // ---------------- page ----------------
  let dashboards = [], contacts = [], fields = [], reportFields = [], currentId = null, viewHost = null;

  async function render(host) {
    viewHost = host;
    host.innerHTML = `<div class="card"><div class="skeleton">Loading…</div></div>`;
    try {
      const [d, c, f] = await Promise.all([App.portalApi("/api/dashboards"), App.portalApi("/api/contacts"), App.portalApi("/api/fields")]);
      dashboards = d; contacts = c; fields = f;
    } catch (e) { host.innerHTML = `<div class="card"><p class="cell-muted">${U().esc(e.message)}</p></div>`; return; }
    reportFields = fields.concat([{ key: "createdAt", label: "Time Created", type: "date" }, { key: "callCount", label: "Number of calls", type: "number" }]);
    if (!currentId && dashboards.length) currentId = dashboards[0].id;
    paint();
  }

  function current() { return dashboards.find((d) => d.id === currentId) || null; }

  function paint() {
    destroyCharts();
    const { el, esc } = U();
    viewHost.innerHTML = "";
    const wrap = el("div", "fade-in");

    const bar = el("div", "reports-bar");
    const left = el("div", "reports-bar-left");
    if (dashboards.length) {
      const sel = el("select", "input reports-select");
      dashboards.forEach((d) => { const o = el("option", null, esc(d.name)); o.value = d.id; if (d.id === currentId) o.selected = true; sel.appendChild(o); });
      sel.onchange = () => { currentId = sel.value; paint(); };
      left.appendChild(sel);
    } else {
      left.appendChild(el("span", "cell-muted", "No dashboards yet"));
    }
    bar.appendChild(left);

    const right = el("div", "reports-bar-right");
    const newDash = el("button", "btn btn-ghost btn-sm", "+ New dashboard");
    newDash.onclick = newDashboard;
    right.appendChild(newDash);
    if (current()) {
      const rename = el("button", "btn btn-ghost btn-sm", "Rename");
      rename.onclick = renameDashboard;
      const del = el("button", "btn btn-ghost btn-sm", "Delete");
      del.onclick = deleteCurrent;
      const addW = el("button", "btn btn-primary btn-sm", "+ Add widget");
      addW.onclick = () => openWidgetEditor(null);
      right.appendChild(rename); right.appendChild(del); right.appendChild(addW);
    }
    bar.appendChild(right);
    wrap.appendChild(bar);

    const dash = current();
    if (!dash) {
      const empty = el("div", "card");
      empty.innerHTML = `<div class="empty"><div class="empty-emoji">📊</div><h3>Create your first dashboard</h3><p>Build KPIs and charts from your contacts data.</p></div>`;
      wrap.appendChild(empty);
      viewHost.appendChild(wrap);
      return;
    }
    const widgets = dash.widgets || [];
    if (!widgets.length) {
      const empty = el("div", "card");
      empty.innerHTML = `<div class="empty"><div class="empty-emoji">➕</div><h3>No widgets yet</h3><p>Add a KPI or chart to this dashboard.</p></div>`;
      wrap.appendChild(empty);
    } else {
      const grid = el("div", "widget-grid");
      widgets.forEach((w) => {
        const card = el("div", "widget-card" + (w.type === "kpi" ? " widget-kpi" : ""));
        const head = el("div", "widget-head");
        head.appendChild(el("div", "widget-title", esc(w.title || "Untitled")));
        const actions = el("div", "widget-actions");
        const edit = el("button", "icon-btn", "✎"); edit.title = "Edit"; edit.onclick = () => openWidgetEditor(w);
        const del = el("button", "icon-btn", "×"); del.title = "Delete"; del.onclick = () => removeWidget(w.id);
        actions.appendChild(edit); actions.appendChild(del);
        head.appendChild(actions);
        card.appendChild(head);
        const bodyHost = el("div", "widget-body");
        card.appendChild(bodyHost);
        grid.appendChild(card);
        try { renderWidgetBody(bodyHost, w, contacts, reportFields); } catch (e) { bodyHost.innerHTML = `<p class="cell-muted">Couldn't render: ${esc(e.message)}</p>`; }
      });
      wrap.appendChild(grid);
    }
    viewHost.appendChild(wrap);
  }

  async function persist(dash) {
    try { await App.portalApi(`/api/dashboards/${dash.id}`, { method: "PATCH", body: JSON.stringify({ name: dash.name, widgets: dash.widgets }) }); }
    catch (e) { U().toast(e.message, true); }
  }
  async function newDashboard() {
    const name = prompt("Dashboard name:", "New dashboard");
    if (!name || !name.trim()) return;
    try { const d = await App.portalApi("/api/dashboards", { method: "POST", body: JSON.stringify({ name: name.trim() }) }); dashboards.push(d); currentId = d.id; paint(); U().toast("Dashboard created"); }
    catch (e) { U().toast(e.message, true); }
  }
  async function renameDashboard() {
    const d = current(); if (!d) return;
    const name = prompt("Rename dashboard:", d.name);
    if (!name || !name.trim()) return;
    d.name = name.trim(); await persist(d); paint();
  }
  async function deleteCurrent() {
    const d = current(); if (!d) return;
    if (!confirm(`Delete dashboard “${d.name}” and its widgets?`)) return;
    try { await App.portalApi(`/api/dashboards/${d.id}`, { method: "DELETE" }); dashboards = dashboards.filter((x) => x.id !== d.id); currentId = dashboards.length ? dashboards[0].id : null; paint(); U().toast("Dashboard deleted"); }
    catch (e) { U().toast(e.message, true); }
  }
  function removeWidget(wid) {
    const d = current(); if (!d) return;
    if (!confirm("Remove this widget?")) return;
    d.widgets = (d.widgets || []).filter((w) => w.id !== wid);
    persist(d); paint();
  }

  // ---------------- widget editor ----------------
  function openWidgetEditor(existing) {
    const { el, esc } = U();
    const dash = current(); if (!dash) return;
    const w = existing ? JSON.parse(JSON.stringify(existing)) : { id: "w" + Date.now(), title: "", type: "kpi", measure: { op: "count" }, groupBy: null, series: null, filters: [] };
    if (!w.measure) w.measure = { op: "count" };

    const numericFields = reportFields.filter((f) => f.type === "number" || f.type === "percent");
    const dimFields = reportFields;

    const inner = el("div");
    inner.innerHTML = `<div class="modal-head"><h2>${existing ? "Edit widget" : "Add widget"}</h2><button class="icon-btn" id="w-close">&times;</button></div>
      <div class="modal-body">
        <label class="field-label">Title</label><input id="w-title" class="input" value="${esc(w.title || "")}" placeholder="e.g. Leads by tier" />
        <label class="field-label">Type</label>
        <select id="w-type" class="input">
          <option value="kpi">KPI (single number)</option>
          <option value="bar">Bar chart</option>
          <option value="stacked">Stacked bar</option>
          <option value="line">Line chart</option>
          <option value="pie">Pie chart</option>
          <option value="heatmap">Heat map</option>
        </select>
        <label class="field-label">Measure</label>
        <div class="w-row">
          <select id="w-mop" class="input"><option value="count">Count of records</option><option value="sum">Sum of…</option><option value="avg">Average of…</option></select>
          <select id="w-mfield" class="input" style="display:none">${numericFields.map((f) => `<option value="${esc(f.key)}">${esc(f.label)}</option>`).join("")}</select>
        </div>
        <div id="w-group-wrap">
          <label class="field-label">Group by</label>
          <div class="w-row">
            <select id="w-group" class="input"><option value="">— none —</option>${dimFields.map((f) => `<option value="${esc(f.key)}">${esc(f.label)}</option>`).join("")}</select>
            <select id="w-groupdate" class="input" style="display:none"><option value="day">By day</option><option value="week">By week</option><option value="month" selected>By month</option><option value="year">By year</option></select>
          </div>
        </div>
        <div id="w-series-wrap" style="display:none">
          <label class="field-label" id="w-series-label">Stack / second dimension</label>
          <select id="w-series" class="input"><option value="">— none —</option>${dimFields.map((f) => `<option value="${esc(f.key)}">${esc(f.label)}</option>`).join("")}</select>
        </div>
        <label class="field-label">Filters</label>
        <div id="w-filters"></div>
        <div class="w-preview-label">Preview</div>
        <div id="w-preview" class="w-preview"></div>
        <button id="w-save" class="btn btn-primary btn-block">${existing ? "Save widget" : "Add widget"}</button>
      </div>`;
    const overlay = modal(inner);
    const $ = (s) => inner.querySelector(s);
    $("#w-close").onclick = () => overlay.remove();
    $("#w-type").value = w.type;
    $("#w-mop").value = w.measure.op;
    if (w.measure.field) $("#w-mfield").value = w.measure.field;
    if (w.groupBy) $("#w-group").value = w.groupBy;
    if (w.groupByDate) $("#w-groupdate").value = w.groupByDate;
    if (w.series) $("#w-series").value = w.series;

    const filtersHost = $("#w-filters");
    filtersHost.appendChild(App.table.ruleEditor(buildColumns(reportFields), contacts, w.filters, () => preview()));

    function selectedGroupIsDate() { const f = reportFields.find((x) => x.key === $("#w-group").value); return f && f.type === "date"; }
    function sync() {
      const type = $("#w-type").value;
      $("#w-mfield").style.display = $("#w-mop").value === "count" ? "none" : "block";
      $("#w-group-wrap").style.display = type === "kpi" ? "none" : "block";
      $("#w-groupdate").style.display = (type !== "kpi" && selectedGroupIsDate()) ? "block" : "none";
      const needsSeries = type === "stacked" || type === "heatmap";
      $("#w-series-wrap").style.display = needsSeries ? "block" : "none";
      $("#w-series-label").textContent = type === "heatmap" ? "Rows (second dimension)" : "Stack by";
      preview();
    }
    function collect() {
      const type = $("#w-type").value;
      const mop = $("#w-mop").value;
      return {
        id: w.id,
        title: $("#w-title").value.trim() || "Untitled",
        type,
        measure: mop === "count" ? { op: "count" } : { op: mop, field: $("#w-mfield").value },
        groupBy: type === "kpi" ? null : ($("#w-group").value || null),
        groupByDate: selectedGroupIsDate() ? $("#w-groupdate").value : null,
        series: (type === "stacked" || type === "heatmap") ? ($("#w-series").value || null) : null,
        filters: w.filters,
      };
    }
    function preview() {
      try { renderWidgetBody($("#w-preview"), collect(), contacts, reportFields); }
      catch (e) { $("#w-preview").innerHTML = `<p class="cell-muted">${esc(e.message)}</p>`; }
    }
    ["#w-type", "#w-mop", "#w-mfield", "#w-group", "#w-groupdate", "#w-series", "#w-title"].forEach((s) => { const n = $(s); n.addEventListener("change", sync); n.addEventListener("input", preview); });
    sync();

    $("#w-save").onclick = async () => {
      const widget = collect();
      const d = current();
      d.widgets = d.widgets || [];
      const idx = d.widgets.findIndex((x) => x.id === widget.id);
      if (idx >= 0) d.widgets[idx] = widget; else d.widgets.push(widget);
      await persist(d);
      overlay.remove();
      paint();
      U().toast(existing ? "Widget saved" : "Widget added");
    };
  }

  function modal(inner) {
    const overlay = U().el("div", "modal-overlay");
    const box = U().el("div", "modal modal-wide");
    box.appendChild(inner);
    overlay.appendChild(box);
    overlay.onclick = (e) => { if (e.target === overlay) overlay.remove(); };
    document.body.appendChild(overlay);
    return overlay;
  }

  App.reports = { render, aggregate, valueOf, bucketDate, measureValue };
})(typeof window !== "undefined" ? window : globalThis);
