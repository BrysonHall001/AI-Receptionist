(function (global) {
  const App = global.App || (global.App = {});
  const U = () => App.util;

  // ---------------- aggregation engine (pure) ----------------
  const SYSTEM = ["name", "phone", "email", "intent"];
  function valueOf(c, key) {
    if (key === "createdAt") return c.createdAt;
    if (key === "callCount") return c.callCount;
    if (SYSTEM.indexOf(key) >= 0) return c[key];
    return (c.customFields || {})[key];
  }
  function scalar(v) {
    if (v == null) return "";
    if (Array.isArray(v)) return v.join(", ");
    if (typeof v === "boolean") return v ? "Yes" : "No";
    return String(v);
  }
  function pad(n) { return n < 10 ? "0" + n : "" + n; }
  function bucketDate(iso, g) {
    const d = new Date(iso);
    if (isNaN(d.getTime())) return "(none)";
    if (g === "day") return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
    if (g === "year") return "" + d.getFullYear();
    if (g === "week") { const onejan = new Date(d.getFullYear(), 0, 1); const wk = Math.ceil(((d - onejan) / 86400000 + onejan.getDay() + 1) / 7); return `${d.getFullYear()}-W${pad(wk)}`; }
    return `${d.getFullYear()}-${pad(d.getMonth() + 1)}`;
  }
  // Normalize a dimension spec into [{key,date}] (supports legacy string form).
  function toDims(v, legacyDate) {
    if (Array.isArray(v)) return v.map((d) => (typeof d === "string" ? { key: d } : d)).filter((d) => d && d.key);
    if (typeof v === "string" && v) return [{ key: v, date: legacyDate }];
    return [];
  }
  function dimMeta(fields, dim) {
    const f = fields.find((x) => x.key === dim.key) || { key: dim.key, label: dim.key, type: "text" };
    return { key: f.key, label: f.label, type: f.type, bucket: dim.date };
  }
  function oneLabel(c, dm) {
    const v = valueOf(c, dm.key);
    if (dm.type === "date") return v ? bucketDate(v, dm.bucket || "month") : "(none)";
    if (v == null || v === "") return "(empty)";
    if (Array.isArray(v)) return v.length ? v.join(", ") : "(empty)";
    if (typeof v === "boolean") return v ? "Yes" : "No";
    return String(v);
  }
  function compoundLabel(c, dims, fields) {
    return dims.map((d) => oneLabel(c, dimMeta(fields, d))).join(" / ");
  }
  function measureValue(rows, measure) {
    if (!measure || measure.op === "count") return rows.length;
    const nums = rows.map((r) => Number(valueOf(r, measure.field))).filter((n) => !isNaN(n));
    if (measure.op === "sum") return nums.reduce((a, b) => a + b, 0);
    if (measure.op === "avg") return nums.length ? +(nums.reduce((a, b) => a + b, 0) / nums.length).toFixed(2) : 0;
    return rows.length;
  }
  function buildColumns(fields) {
    return fields.map((f) => ({ key: f.key, label: f.label, type: f.type === "percent" ? "number" : f.type, get: (r) => valueOf(r, f.key), text: (r) => scalar(valueOf(r, f.key)) }));
  }
  function groupRows(rows, dims, fields) {
    const map = new Map();
    rows.forEach((r) => { const k = compoundLabel(r, dims, fields); if (!map.has(k)) map.set(k, []); map.get(k).push(r); });
    return map;
  }
  const CAP = 40;
  function measureLabel(m, fields) {
    if (!m || m.op === "count") return "Count";
    const f = fields.find((x) => x.key === m.field);
    const fl = f ? f.label : m.field;
    return (m.op === "sum" ? "Sum of " : "Average of ") + fl;
  }
  function aggregate(contacts, fields, w) {
    const cols = buildColumns(fields);
    const filtered = (App.table && App.table.pipeline) ? App.table.pipeline(contacts, cols, { rules: w.filters || [] }) : contacts.slice();
    const measure = w.measure || { op: "count" };
    if (w.type === "kpi") return { kind: "kpi", value: measureValue(filtered, measure) };

    const groupDims = toDims(w.groupBy, w.groupByDate);
    if (!groupDims.length) return { kind: "kpi", value: measureValue(filtered, measure) };
    const seriesDims = toDims(w.series, w.seriesDate);

    if (w.type === "stacked" || w.type === "heatmap") {
      const xMap = groupRows(filtered, groupDims, fields);
      let labels = Array.from(xMap.keys()).sort();
      if (labels.length > CAP) labels = labels.slice(0, CAP);
      const seriesNames = seriesDims.length ? Array.from(new Set(filtered.map((r) => compoundLabel(r, seriesDims, fields)))).sort().slice(0, CAP) : ["All"];
      const series = seriesNames.map((sn) => ({
        name: sn,
        data: labels.map((lab) => {
          const rows = (xMap.get(lab) || []).filter((r) => !seriesDims.length || compoundLabel(r, seriesDims, fields) === sn);
          return measureValue(rows, measure);
        }),
      }));
      if (w.type === "heatmap") { let max = 0; series.forEach((s) => s.data.forEach((v) => { if (v > max) max = v; })); return { kind: "heatmap", cols: labels, rows: seriesNames, series, max }; }
      return { kind: "stacked", labels, series, measureLabel: measureLabel(measure, fields) };
    }

    const map = groupRows(filtered, groupDims, fields);
    let entries = Array.from(map.entries()).map(([label, rows]) => [label, measureValue(rows, measure)]);
    const isDate = groupDims.length === 1 && dimMeta(fields, groupDims[0]).type === "date";
    entries.sort((a, b) => (isDate ? String(a[0]).localeCompare(String(b[0])) : b[1] - a[1]));
    if (entries.length > CAP) entries = entries.slice(0, CAP);
    return { kind: "series", labels: entries.map((e) => e[0]), data: entries.map((e) => e[1]), measureLabel: measureLabel(measure, fields) };
  }

  // ---------------- rendering ----------------
  const PALETTE = ["#5b5bd6", "#3aa675", "#e0a23b", "#c2453f", "#3b82c4", "#8a4fc4", "#d2689a", "#4cae9e", "#9a8a3b", "#6b7280"];
  let activeCharts = [];
  function destroyCharts() { activeCharts.forEach((c) => { try { c.destroy(); } catch (e) {} }); activeCharts = []; }

  function renderWidgetBody(host, w, contacts, fields) {
    const agg = aggregate(contacts, fields, w);
    host.innerHTML = "";
    if (agg.kind === "kpi") {
      const k = U().el("div", "kpi");
      k.appendChild(U().el("div", "kpi-value", String(agg.value)));
      k.appendChild(U().el("div", "kpi-label", measureLabel(w.measure, fields)));
      host.appendChild(k);
      return;
    }
    if (agg.kind === "heatmap") { renderHeatmap(host, agg); return; }
    if (typeof Chart === "undefined") { host.innerHTML = `<p class="cell-muted">Charts need an internet connection.</p>`; return; }
    const canvas = document.createElement("canvas");
    host.appendChild(canvas);
    let config;
    if (agg.kind === "stacked") {
      config = { type: "bar", data: { labels: agg.labels, datasets: agg.series.map((s, i) => ({ label: s.name, data: s.data, backgroundColor: PALETTE[i % PALETTE.length] })) }, options: baseOpts(true) };
    } else if (w.type === "pie") {
      config = { type: "pie", data: { labels: agg.labels, datasets: [{ data: agg.data, backgroundColor: agg.labels.map((_, i) => PALETTE[i % PALETTE.length]) }] }, options: baseOpts(false, true) };
    } else if (w.type === "line") {
      config = { type: "line", data: { labels: agg.labels, datasets: [{ label: agg.measureLabel, data: agg.data, borderColor: PALETTE[0], backgroundColor: "rgba(91,91,214,0.15)", tension: 0.3, fill: true }] }, options: baseOpts(false) };
    } else {
      config = { type: "bar", data: { labels: agg.labels, datasets: [{ label: agg.measureLabel, data: agg.data, backgroundColor: PALETTE[0] }] }, options: baseOpts(false) };
    }
    activeCharts.push(new Chart(canvas, config));
  }
  function baseOpts(stacked, hideScales) {
    const o = { responsive: true, maintainAspectRatio: false, plugins: { legend: { display: stacked || hideScales } } };
    if (!hideScales) o.scales = { x: { stacked: !!stacked, ticks: { maxRotation: 60, minRotation: 0 } }, y: { stacked: !!stacked, beginAtZero: true } };
    return o;
  }
  function renderHeatmap(host, agg) {
    const { el, esc } = U();
    const table = el("table", "heatmap");
    const thead = el("thead"); const htr = el("tr"); htr.appendChild(el("th", "", ""));
    agg.cols.forEach((c) => htr.appendChild(el("th", "", esc(c)))); thead.appendChild(htr); table.appendChild(thead);
    const tb = el("tbody");
    agg.rows.forEach((rowName, ri) => {
      const tr = el("tr"); tr.appendChild(el("th", "", esc(rowName)));
      agg.cols.forEach((_, ci) => {
        const v = agg.series[ri] ? agg.series[ri].data[ci] : 0;
        const intensity = agg.max ? v / agg.max : 0;
        const td = el("td", "hm-cell", String(v));
        td.style.background = `rgba(91,91,214,${0.08 + intensity * 0.72})`;
        if (intensity > 0.6) td.style.color = "#fff";
        tr.appendChild(td);
      });
      tb.appendChild(tr);
    });
    table.appendChild(tb);
    const wrap = el("div", "heatmap-wrap"); wrap.appendChild(table); host.appendChild(wrap);
  }

  // ---------------- page ----------------
  let dashboards = [], contacts = [], fields = [], reportFields = [], currentId = null, viewHost = null, editMode = false;

  async function render(host) {
    viewHost = host;
    host.innerHTML = `<div class="card"><div class="skeleton">Loading…</div></div>`;
    try {
      const [d, c, f] = await Promise.all([App.portalApi("/api/dashboards"), App.portalApi("/api/contacts"), App.portalApi("/api/fields")]);
      dashboards = d; contacts = c; fields = f;
    } catch (e) { host.innerHTML = `<div class="card"><p class="cell-muted">${U().esc(e.message)}</p></div>`; return; }
    reportFields = fields.concat([{ key: "createdAt", label: "Time Created", type: "date" }, { key: "callCount", label: "Number of calls", type: "number" }]);
    if (!currentId && dashboards.length) currentId = dashboards[0].id;
    paint();
  }
  function current() { return dashboards.find((d) => d.id === currentId) || null; }

  function paint() {
    destroyCharts();
    const { el, esc } = U();
    viewHost.innerHTML = "";
    const wrap = el("div", "fade-in");

    const bar = el("div", "reports-bar");
    const left = el("div", "reports-bar-left");
    if (dashboards.length) {
      const sel = el("select", "input reports-select");
      dashboards.forEach((d) => { const o = el("option", null, esc(d.name)); o.value = d.id; if (d.id === currentId) o.selected = true; sel.appendChild(o); });
      sel.onchange = () => { currentId = sel.value; editMode = false; paint(); };
      left.appendChild(sel);
    } else left.appendChild(el("span", "cell-muted", "No dashboards yet"));
    bar.appendChild(left);

    const right = el("div", "reports-bar-right");
    const newDash = el("button", "btn btn-ghost btn-sm", "+ New dashboard");
    newDash.onclick = newDashboard;
    right.appendChild(newDash);
    if (current()) {
      const editBtn = el("button", "btn btn-sm " + (editMode ? "btn-primary" : "btn-ghost"), editMode ? "✓ Done editing" : "✎ Edit layout");
      editBtn.onclick = () => { editMode = !editMode; paint(); };
      const rename = el("button", "btn btn-ghost btn-sm", "Rename");
      rename.onclick = renameDashboard;
      const del = el("button", "btn btn-ghost btn-sm", "Delete dashboard");
      del.onclick = deleteCurrent;
      const addW = el("button", "btn btn-primary btn-sm", "+ Add widget");
      addW.onclick = () => openWidgetEditor(null);
      right.appendChild(editBtn); right.appendChild(rename); right.appendChild(del); right.appendChild(addW);
    }
    bar.appendChild(right);
    wrap.appendChild(bar);

    const dash = current();
    if (!dash) {
      const empty = el("div", "card");
      empty.innerHTML = `<div class="empty"><div class="empty-emoji">📊</div><h3>Create your first dashboard</h3><p>Build KPIs and charts from your contacts data.</p></div>`;
      wrap.appendChild(empty); viewHost.appendChild(wrap); return;
    }
    if (editMode) wrap.appendChild(el("div", "reports-hint", "Drag widgets to reorder. Use the width control to resize. Changes save automatically."));
    const widgets = dash.widgets || [];
    if (!widgets.length) {
      const empty = el("div", "card");
      empty.innerHTML = `<div class="empty"><div class="empty-emoji">➕</div><h3>No widgets yet</h3><p>Add a KPI or chart to this dashboard.</p></div>`;
      wrap.appendChild(empty);
    } else {
      const grid = el("div", "widget-grid");
      widgets.forEach((w) => grid.appendChild(widgetCard(w, dash)));
      wrap.appendChild(grid);
    }
    viewHost.appendChild(wrap);
  }

  function widgetCard(w, dash) {
    const { el, esc } = U();
    const card = el("div", "widget-card" + (w.type === "kpi" ? " widget-kpi" : "") + (editMode ? " editing" : ""));
    card.dataset.id = w.id;
    card.style.gridColumn = "span " + (w.w || 1);
    if (editMode) card.draggable = true;

    const head = el("div", "widget-head");
    const titleWrap = el("div", "widget-title-wrap");
    if (editMode) titleWrap.appendChild(el("span", "drag-handle", "⠿"));
    titleWrap.appendChild(el("div", "widget-title", esc(w.title || "Untitled")));
    head.appendChild(titleWrap);

    const actions = el("div", "widget-actions");
    if (editMode) {
      const widthSel = el("select", "w-size-select");
      [["1", "Normal"], ["2", "Wide"], ["3", "Full"]].forEach(([v, lbl]) => { const o = el("option", null, lbl); o.value = v; if (String(w.w || 1) === v) o.selected = true; widthSel.appendChild(o); });
      widthSel.onchange = () => { w.w = parseInt(widthSel.value, 10); persist(dash); card.style.gridColumn = "span " + w.w; };
      widthSel.onclick = (e) => e.stopPropagation();
      actions.appendChild(widthSel);
    }
    const dup = el("button", "icon-btn", "⧉"); dup.title = "Duplicate"; dup.onclick = () => openDuplicate(w);
    const edit = el("button", "icon-btn", "✎"); edit.title = "Edit"; edit.onclick = () => openWidgetEditor(w);
    const del = el("button", "icon-btn", "×"); del.title = "Delete"; del.onclick = () => removeWidget(w.id);
    actions.appendChild(dup); actions.appendChild(edit); actions.appendChild(del);
    head.appendChild(actions);
    card.appendChild(head);

    const bodyHost = el("div", "widget-body");
    card.appendChild(bodyHost);
    try { renderWidgetBody(bodyHost, w, contacts, reportFields); } catch (e) { bodyHost.innerHTML = `<p class="cell-muted">Couldn't render: ${esc(e.message)}</p>`; }

    if (editMode) {
      card.addEventListener("dragstart", (e) => { card.classList.add("dragging"); e.dataTransfer.effectAllowed = "move"; });
      card.addEventListener("dragend", () => { card.classList.remove("dragging"); saveOrder(card.parentElement, dash); });
      card.addEventListener("dragover", (e) => { e.preventDefault(); const d = card.parentElement.querySelector(".dragging"); if (!d || d === card) return; const r = card.getBoundingClientRect(); const after = (e.clientY - r.top) / r.height > 0.5 || (e.clientX - r.left) / r.width > 0.5; card.parentElement.insertBefore(d, after ? card.nextSibling : card); });
    }
    return card;
  }

  function saveOrder(grid, dash) {
    const ids = U().$$(".widget-card", grid).map((c) => c.dataset.id);
    dash.widgets.sort((a, b) => ids.indexOf(a.id) - ids.indexOf(b.id));
    persist(dash);
  }

  async function persist(dash) {
    try { await App.portalApi(`/api/dashboards/${dash.id}`, { method: "PATCH", body: JSON.stringify({ name: dash.name, widgets: dash.widgets }) }); }
    catch (e) { U().toast(e.message, true); }
  }
  async function newDashboard() {
    const name = prompt("Dashboard name:", "New dashboard");
    if (!name || !name.trim()) return;
    try { const d = await App.portalApi("/api/dashboards", { method: "POST", body: JSON.stringify({ name: name.trim() }) }); dashboards.push(d); currentId = d.id; paint(); U().toast("Dashboard created"); }
    catch (e) { U().toast(e.message, true); }
  }
  async function renameDashboard() {
    const d = current(); if (!d) return;
    const name = prompt("Rename dashboard:", d.name);
    if (!name || !name.trim()) return;
    d.name = name.trim(); await persist(d); paint();
  }
  async function deleteCurrent() {
    const d = current(); if (!d) return;
    if (!confirm(`Delete dashboard “${d.name}” and its widgets?`)) return;
    try { await App.portalApi(`/api/dashboards/${d.id}`, { method: "DELETE" }); dashboards = dashboards.filter((x) => x.id !== d.id); currentId = dashboards.length ? dashboards[0].id : null; editMode = false; paint(); U().toast("Dashboard deleted"); }
    catch (e) { U().toast(e.message, true); }
  }
  function removeWidget(wid) {
    const d = current(); if (!d) return;
    if (!confirm("Remove this widget?")) return;
    d.widgets = (d.widgets || []).filter((w) => w.id !== wid);
    persist(d); paint();
  }

  // ---------------- duplicate ----------------
  function openDuplicate(w) {
    const { el, esc } = U();
    const inner = el("div");
    inner.innerHTML = `<div class="modal-head"><h2>Duplicate widget</h2><button class="icon-btn" id="d-close">&times;</button></div>
      <div class="modal-body">
        <label class="field-label">Copy “${esc(w.title || "Untitled")}” to dashboard:</label>
        <select id="d-target" class="input">${dashboards.map((d) => `<option value="${d.id}"${d.id === currentId ? " selected" : ""}>${esc(d.name)}</option>`).join("")}</select>
        <button id="d-go" class="btn btn-primary btn-block" style="margin-top:14px">Duplicate</button>
      </div>`;
    const overlay = modal(inner);
    inner.querySelector("#d-close").onclick = () => overlay.remove();
    inner.querySelector("#d-go").onclick = async () => {
      const targetId = inner.querySelector("#d-target").value;
      const target = dashboards.find((d) => d.id === targetId);
      if (!target) return;
      const copy = JSON.parse(JSON.stringify(w));
      copy.id = "w" + Date.now();
      copy.title = (w.title || "Untitled") + " (copy)";
      target.widgets = target.widgets || [];
      target.widgets.push(copy);
      await persist(target);
      overlay.remove();
      U().toast(targetId === currentId ? "Widget duplicated" : `Copied to “${target.name}”`);
      if (targetId === currentId) paint();
    };
  }

  // ---------------- widget editor ----------------
  function dimListEditor(host, fields, initialDims, onChange) {
    const { el } = U();
    const rows = [];
    const list = el("div", "dim-list");
    host.appendChild(list);
    const addBtn = el("button", "btn btn-ghost btn-sm", "+ Add dimension");
    host.appendChild(addBtn);
    function addRow(initial) {
      const row = el("div", "dim-row");
      const sel = el("select", "input");
      const blank = el("option", null, "— select —"); blank.value = ""; sel.appendChild(blank);
      fields.forEach((f) => { const o = el("option", null, f.label); o.value = f.key; sel.appendChild(o); });
      const dateSel = el("select", "input"); [["day", "By day"], ["week", "By week"], ["month", "By month"], ["year", "By year"]].forEach(([v, l]) => { const o = el("option", null, l); o.value = v; if (v === "month") o.selected = true; dateSel.appendChild(o); });
      dateSel.style.display = "none";
      const rm = el("button", "icon-btn", "×"); rm.title = "Remove";
      const entry = { get: () => { if (!sel.value) return null; const f = fields.find((x) => x.key === sel.value); return f && f.type === "date" ? { key: sel.value, date: dateSel.value } : { key: sel.value }; } };
      function syncDate() { const f = fields.find((x) => x.key === sel.value); dateSel.style.display = f && f.type === "date" ? "" : "none"; }
      sel.onchange = () => { syncDate(); onChange && onChange(); };
      dateSel.onchange = () => onChange && onChange();
      rm.onclick = () => { list.removeChild(row); const i = rows.indexOf(entry); if (i >= 0) rows.splice(i, 1); onChange && onChange(); };
      if (initial) { sel.value = initial.key; if (initial.date) dateSel.value = initial.date; }
      syncDate();
      row.appendChild(sel); row.appendChild(dateSel); row.appendChild(rm);
      rows.push(entry); list.appendChild(row);
    }
    (initialDims && initialDims.length ? initialDims : []).forEach(addRow);
    addBtn.onclick = () => { addRow(null); onChange && onChange(); };
    return { getDims: () => rows.map((r) => r.get()).filter(Boolean) };
  }

  function openWidgetEditor(existing) {
    const { el, esc } = U();
    const dash = current(); if (!dash) return;
    const w = existing ? JSON.parse(JSON.stringify(existing)) : { id: "w" + Date.now(), title: "", type: "kpi", measure: { op: "count" }, groupBy: [], series: [], filters: [], w: 1 };
    if (!w.measure) w.measure = { op: "count" };
    const numericFields = reportFields.filter((f) => f.type === "number" || f.type === "percent");

    const inner = el("div");
    inner.innerHTML = `<div class="modal-head"><h2>${existing ? "Edit widget" : "Add widget"}</h2><button class="icon-btn" id="w-close">&times;</button></div>
      <div class="modal-body">
        <label class="field-label">Title</label><input id="w-title" class="input" value="${esc(w.title || "")}" placeholder="e.g. Leads by tier" />
        <label class="field-label">Type</label>
        <select id="w-type" class="input">
          <option value="kpi">KPI (single number)</option>
          <option value="bar">Bar chart</option>
          <option value="stacked">Stacked bar</option>
          <option value="line">Line chart</option>
          <option value="pie">Pie chart</option>
          <option value="heatmap">Heat map</option>
        </select>
        <label class="field-label">Measure</label>
        <div class="w-row">
          <select id="w-mop" class="input"><option value="count">Count of records</option><option value="sum">Sum of…</option><option value="avg">Average of…</option></select>
          <select id="w-mfield" class="input" style="display:none">${numericFields.map((f) => `<option value="${esc(f.key)}">${esc(f.label)}</option>`).join("")}</select>
        </div>
        <div id="w-group-wrap"><label class="field-label">Group by</label><div id="w-group"></div></div>
        <div id="w-series-wrap" style="display:none"><label class="field-label" id="w-series-label">Stack by</label><div id="w-series"></div></div>
        <label class="field-label">Filters</label>
        <div id="w-filters"></div>
        <div class="w-preview-label">Preview</div>
        <div id="w-preview" class="w-preview"></div>
        <button id="w-save" class="btn btn-primary btn-block">${existing ? "Save widget" : "Add widget"}</button>
      </div>`;
    const overlay = modal(inner);
    const $ = (s) => inner.querySelector(s);
    $("#w-close").onclick = () => overlay.remove();
    $("#w-type").value = w.type;
    $("#w-mop").value = w.measure.op;
    if (w.measure.field) $("#w-mfield").value = w.measure.field;

    const groupEd = dimListEditor($("#w-group"), reportFields, toDims(w.groupBy, w.groupByDate), () => preview());
    const seriesEd = dimListEditor($("#w-series"), reportFields, toDims(w.series, w.seriesDate), () => preview());
    $("#w-filters").appendChild(App.table.ruleEditor(buildColumns(reportFields), contacts, w.filters, () => preview()));

    function sync() {
      const type = $("#w-type").value;
      $("#w-mfield").style.display = $("#w-mop").value === "count" ? "none" : "block";
      $("#w-group-wrap").style.display = type === "kpi" ? "none" : "block";
      const needsSeries = type === "stacked" || type === "heatmap";
      $("#w-series-wrap").style.display = needsSeries ? "block" : "none";
      $("#w-series-label").textContent = type === "heatmap" ? "Rows (second dimension)" : "Stack by";
      preview();
    }
    function collect() {
      const type = $("#w-type").value;
      const mop = $("#w-mop").value;
      return {
        id: w.id, title: $("#w-title").value.trim() || "Untitled", type,
        measure: mop === "count" ? { op: "count" } : { op: mop, field: $("#w-mfield").value },
        groupBy: type === "kpi" ? [] : groupEd.getDims(),
        series: (type === "stacked" || type === "heatmap") ? seriesEd.getDims() : [],
        filters: w.filters, w: w.w || 1,
      };
    }
    function preview() { try { renderWidgetBody($("#w-preview"), collect(), contacts, reportFields); } catch (e) { $("#w-preview").innerHTML = `<p class="cell-muted">${esc(e.message)}</p>`; } }
    ["#w-type", "#w-mop", "#w-mfield", "#w-title"].forEach((s) => { $(s).addEventListener("change", sync); $(s).addEventListener("input", preview); });
    sync();

    $("#w-save").onclick = async () => {
      const widget = collect();
      const d = current(); d.widgets = d.widgets || [];
      const idx = d.widgets.findIndex((x) => x.id === widget.id);
      if (idx >= 0) d.widgets[idx] = widget; else d.widgets.push(widget);
      await persist(d); overlay.remove(); paint();
      U().toast(existing ? "Widget saved" : "Widget added");
    };
  }

  function modal(inner) {
    const overlay = U().el("div", "modal-overlay");
    const box = U().el("div", "modal modal-wide");
    box.appendChild(inner);
    overlay.appendChild(box);
    overlay.onclick = (e) => { if (e.target === overlay) overlay.remove(); };
    document.body.appendChild(overlay);
    return overlay;
  }

  App.reports = { render, aggregate, valueOf, bucketDate, measureValue };
})(typeof window !== "undefined" ? window : globalThis);
