(function (global) {
  const App = global.App || (global.App = {});
  const { el, esc, toast } = App.util;

  const FONTS = ["Default", "Arial", "Georgia", "Times New Roman", "Courier New", "Verdana", "Tahoma", "Trebuchet MS", "Helvetica"];
  const SIZES = [["2", "Small"], ["3", "Normal"], ["5", "Large"], ["6", "X-Large"]];

  function exec(cmd, val) {
    try { document.execCommand("styleWithCSS", false, true); } catch (e) {}
    document.execCommand(cmd, false, val == null ? null : val);
  }

  // Mount a composer into host. opts: { kind: 'email'|'sms' }.
  // Returns { getSubject, setSubject, getHTML, getText, setBody, focus }.
  function mount(host, opts) {
    opts = opts || {};
    const kind = opts.kind === "sms" ? "sms" : "email";
    host.innerHTML = "";

    let subjectInput = null;
    if (kind === "email") {
      host.appendChild(el("label", "field-label", "Subject"));
      subjectInput = el("input", "input");
      subjectInput.placeholder = "Subject";
      host.appendChild(subjectInput);
    }

    // Action buttons row (templates / signature / header image)
    const actions = el("div", "compose-actions");
    const tplWrap = el("div", "saved-wrap");
    const tplBtn = el("button", "btn btn-ghost btn-sm", "Templates &#9662;");
    const tplMenu = el("div", "saved-menu hidden");
    tplWrap.appendChild(tplBtn); tplWrap.appendChild(tplMenu);
    actions.appendChild(tplWrap);

    if (kind === "email") {
      const sigBtn = el("button", "btn btn-ghost btn-sm", "Insert signature");
      sigBtn.onclick = insertSignature;
      actions.appendChild(sigBtn);
      const hdrBtn = el("button", "btn btn-ghost btn-sm", "Header image");
      const hdrFile = el("input"); hdrFile.type = "file"; hdrFile.accept = "image/*"; hdrFile.style.display = "none";
      hdrBtn.onclick = () => hdrFile.click();
      hdrFile.onchange = () => {
        const f = hdrFile.files[0]; if (!f) return;
        if (f.size > 1024 * 1024) { toast("Image must be under 1 MB", true); hdrFile.value = ""; return; }
        const r = new FileReader();
        r.onload = () => { body.innerHTML = `<img class="email-header-img" src="${r.result}" style="max-width:100%;display:block;margin:0 0 12px" /><p></p>` + body.innerHTML; };
        r.readAsDataURL(f);
      };
      actions.appendChild(hdrBtn);
      actions.appendChild(hdrFile);
    }
    host.appendChild(actions);

    let body;
    if (kind === "email") {
      const toolbar = el("div", "email-toolbar wrap");
      const fontSel = el("select", "tb-select");
      FONTS.forEach((f) => { const o = el("option", null, f); o.value = f === "Default" ? "" : f; fontSel.appendChild(o); });
      fontSel.onchange = () => { if (fontSel.value) exec("fontName", fontSel.value); };
      const sizeSel = el("select", "tb-select");
      SIZES.forEach(([v, lbl]) => { const o = el("option", null, lbl); o.value = v; if (v === "3") o.selected = true; sizeSel.appendChild(o); });
      sizeSel.onchange = () => exec("fontSize", sizeSel.value);
      const color = el("input", "tb-color"); color.type = "color"; color.value = "#1f1f29"; color.title = "Text color";
      color.oninput = () => exec("foreColor", color.value);
      toolbar.appendChild(fontSel); toolbar.appendChild(sizeSel); toolbar.appendChild(color);
      [["bold", "<b>B</b>"], ["italic", "<i>I</i>"], ["underline", "<u>U</u>"],
       ["justifyLeft", "&#8676;"], ["justifyCenter", "&#8596;"], ["justifyRight", "&#8677;"],
       ["insertUnorderedList", "&bull; List"], ["insertOrderedList", "1. List"],
       ["outdent", "&#8676;|"], ["indent", "|&#8677;"], ["createLink", "&#128279;"]].forEach(([cmd, label]) => {
        const b = el("button", null, label);
        b.onclick = (e) => { e.preventDefault(); if (cmd === "createLink") { const u = prompt("Link URL:"); if (u) exec(cmd, u); } else exec(cmd); body.focus(); };
        toolbar.appendChild(b);
      });
      host.appendChild(toolbar);
      body = el("div", "email-body"); body.contentEditable = "true";
      host.appendChild(body);
    } else {
      body = el("textarea", "input sms-body"); body.rows = 5; body.placeholder = "Type your message…";
      host.appendChild(body);
      const counter = el("div", "sms-count muted"); counter.textContent = "0 characters";
      body.oninput = () => { counter.textContent = `${body.value.length} characters`; };
      host.appendChild(counter);
    }

    // ---- Signature ----
    let signatureHtml = "";
    if (kind === "email") {
      App.portalApi("/api/account/signature").then((r) => { signatureHtml = (r && r.signature) || ""; }).catch(() => {});
    }
    function insertSignature() {
      if (!signatureHtml) { toast("Set a signature in Settings first", true); return; }
      body.innerHTML = body.innerHTML + `<br><br>` + signatureHtml;
    }

    // ---- Templates ----
    let templates = [];
    async function loadTemplates() {
      try { templates = await App.portalApi(`/api/templates?kind=${kind}`); } catch (e) { templates = []; }
      paintTemplates();
    }
    function paintTemplates() {
      tplMenu.innerHTML = "";
      if (!templates.length) tplMenu.appendChild(el("div", "saved-empty", "No templates yet"));
      templates.forEach((t) => {
        const row = el("div", "saved-item");
        const name = el("button", "saved-name", esc(t.name));
        name.onclick = () => { if (kind === "email") { if (subjectInput && t.subject) subjectInput.value = t.subject; body.innerHTML = t.body || ""; } else { body.value = t.body || ""; body.dispatchEvent(new Event("input")); } tplMenu.classList.add("hidden"); toast(`Loaded “${t.name}”`); };
        const del = el("button", "saved-del", "&times;");
        del.onclick = async (e) => { e.stopPropagation(); if (!confirm(`Delete template “${t.name}”?`)) return; try { await App.portalApi(`/api/templates/${t.id}`, { method: "DELETE" }); toast("Template deleted"); loadTemplates(); } catch (err) { toast(err.message, true); } };
        row.appendChild(name); row.appendChild(del);
        tplMenu.appendChild(row);
      });
      tplMenu.appendChild(el("div", "pop-sep"));
      const save = el("button", "saved-save", "+ Save current as template");
      save.onclick = async () => {
        const name = prompt("Name this template:");
        if (!name || !name.trim()) return;
        const payload = kind === "email"
          ? { name: name.trim(), kind: "email", subject: subjectInput ? subjectInput.value : "", body: body.innerHTML }
          : { name: name.trim(), kind: "sms", body: body.value };
        try { await App.portalApi("/api/templates", { method: "POST", body: JSON.stringify(payload) }); toast("Template saved"); loadTemplates(); }
        catch (err) { toast(err.message, true); }
      };
      tplMenu.appendChild(save);
    }
    tplBtn.onclick = (e) => { e.stopPropagation(); tplMenu.classList.toggle("hidden"); if (!tplMenu.classList.contains("hidden")) setTimeout(() => document.addEventListener("click", closeTpl, { once: true }), 0); };
    function closeTpl() { tplMenu.classList.add("hidden"); }
    tplMenu.addEventListener("click", (e) => e.stopPropagation());
    loadTemplates();

    return {
      getSubject: () => (subjectInput ? subjectInput.value.trim() : ""),
      setSubject: (s) => { if (subjectInput) subjectInput.value = s; },
      getHTML: () => (kind === "email" ? body.innerHTML : body.value),
      getText: () => (kind === "email" ? body.innerText : body.value),
      setBody: (html) => { if (kind === "email") body.innerHTML = html; else body.value = html; },
      focus: () => body.focus(),
    };
  }

  App.compose = { mount };
})(typeof window !== "undefined" ? window : globalThis);
